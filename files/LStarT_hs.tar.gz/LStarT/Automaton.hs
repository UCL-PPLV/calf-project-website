module LStarT.Automaton
    (
        Aut (Aut, initial, delta, out),
        reach,
        autLang,
        idAut,
        bisimT,
        bisim,
        concreteBisimT,
        SAut (SAut, sinitial, sdelta, sout),
        det,
        autSize,
        randomSAutByMap,
        randomSAut
    )
where

import Data.List
import Control.Monad
import Control.Monad.Trans.State
import Data.Functor.Identity
import Data.Map (Map)
import qualified Data.Map as Map
import System.Random

import LStarT.Utils

data Aut a o q = Aut {
    initial ::
        q,
    delta ::
        q -> a -> q,
    out ::
        q -> o
}

reach ::
    Aut a o q -> [a] -> q
reach x =
    foldl' (delta x) (initial x)

autLang ::
    Aut a o q -> [a] -> o
autLang x =
    out x . reach x

idAut ::
    Aut a o q -> Aut a o (Identity q)
idAut aut =
    let
        i =
            return $ initial aut
        d =
            extend runIdentity $ \q -> return . delta aut q
        o =
            extend runIdentity $ out aut
    in
    Aut {initial = i, delta = d, out = o}

bisimT :: (Eq o) =>
    ((t q, t r) -> [(t q, t r)] -> Bool) -> [a] -> Aut a o (t q) -> Aut a o (t r) -> Maybe [a]
bisimT elemt alph x y =
    let
        i =
            (initial x, initial y)
        bisimT' done todo =
            case todo of
                [] ->
                    Nothing
                (u, (q, r)) : todo' ->
                    if out x q == out y r then
                        let
                            progress a new' =
                                let
                                    t =
                                        (delta x q a, delta y r a)
                                in
                                if t `elemt` (done ++ map snd new') then
                                    new'
                                else
                                    (u ++ [a], t) : new'
                            new =
                                foldr progress [] alph
                        in
                        bisimT' (done ++ map snd new) $ todo' ++ new
                    else
                        Just u
    in
    bisimT' [i] [([], i)]

bisim :: (Eq q, Eq r, Eq o) =>
    [a] -> Aut a o q -> Aut a o r -> Maybe [a]
bisim alph x y =
    bisimT elem alph (idAut x) (idAut y)

concreteBisimT :: (Concrete t, Monad t, Ord (t q), Ord (t r), Eq o) =>
    [a] -> Aut a o (t q) -> Aut a o (t r) -> Maybe [a]
concreteBisimT =
    bisimT $ \t l ->
        t `elem` map (pair (join . fmap fst, join . fmap snd)) (concreteApply l)

data SAut t a o q = SAut {
    sinitial ::
        t q,
    sdelta ::
        Map q (Map a (t q)),
    sout ::
        Map q o
} deriving Show

det :: (Monad t, Ord q, Ord a) =>
    Alg t (a -> t q) -> Alg t o -> SAut t a o q -> Aut a o (t q)
det dist alg x =
    let
        initial =
            sinitial x
        delta =
            extend dist (\q a -> (sdelta x) Map.! q Map.! a)
        out =
            extend alg ((Map.!) (sout x))
    in
    Aut {initial = initial, delta = delta, out = out}

autSize ::
    SAut t a o q -> Int
autSize x =
    length . Map.keys $ sout x

randomSAutByMap ::
    State StdGen (t q) -> State StdGen (Map q (Map a (t q))) -> State StdGen (Map q o) -> State StdGen (SAut t a o q)
randomSAutByMap rq rd ro =
    do
        i <- rq
        d <- rd
        o <- ro
        return SAut {sinitial = i, sdelta = d, sout = o}

randomSAut :: (Ord a, Ord q) =>
    [a] -> State StdGen o -> [q] -> State StdGen (t q) -> State StdGen (SAut t a o q)
randomSAut as ro qs rq =
    let
        rd =
            do
                l <- mapM (const $ randomMap as rq) qs
                return $ Map.fromList $ zip qs l
    in
    randomSAutByMap rq rd (randomMap qs ro)
