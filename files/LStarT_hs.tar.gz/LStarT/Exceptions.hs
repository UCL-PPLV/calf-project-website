module LStarT.Exceptions (eitherAlg) where

import LStarT.Utils

instance Supported (Either e) where
    supp either =
        case either of
            Left e ->
                []
            Right a ->
                [a]

instance Enumerable e => Concrete (Either e) where
    concreteApply l =
        map Left enumerate ++ map Right l

eitherAlg ::
    (e -> a) -> Alg (Either e) a
eitherAlg f =
    either f id
