{-# LANGUAGE MultiParamTypeClasses #-}

module LStarT.NonDeterminism
    (
        FSet,
        crfsaDecompose,
        scrfsaDecompose,
        bolligConsistency,
        randomFSet,
        nonDetAlg,
        universalAlg
    )
where

import Control.Monad
import Data.Maybe
import Data.Set (Set)
import qualified Data.Set as Set
import Data.Map (Map)
import qualified Data.Map as Map
import System.Random

import LStarT.LStarT
import LStarT.CFree
import LStarT.Utils

instance ConstrainedMonad Ord Set where
    constrainedReturn =
        Set.singleton
    s `constrainedBind` f =
        Set.unions [f a | a <- Set.toList s]

type FSet =
    CFree Ord Set

instance Supported Set where
    supp =
        Set.toList

instance Concrete Set where
    concreteApply =
        foldr (\a -> foldr (\s l -> s : Set.insert a s : l) []) [Set.empty]

lesserRow :: (Ord o) =>
    (Int -> Alg FSet [o]) -> [o] -> [o] -> Bool
lesserRow alg a b =
    alg (length a) (inject $ Set.fromList [a, b]) == b

setDecompose :: (Ord a, Ord o) =>
    Alg FSet [o] -> [([a], [o])] -> [o] -> Maybe (FSet [a])
setDecompose alg rows row =
    let
        rowSet =
            inject . Set.fromList $ map snd rows
        labelSet =
            inject . Set.fromList $ map fst rows
    in
    if alg rowSet == row then
        Just labelSet
    else
        Nothing

lesserRows :: (Ord a, Ord o) =>
    (Int -> Alg FSet [o]) -> ObservationTable a o -> [[a]] -> [o] -> [([a], [o])]
lesserRows alg ot labels row =
    [(u, getRowU ot u) | u <- labels, let row' = getRowU ot u, lesserRow alg row' row]

crfsaDecompose :: (Ord a, Ord o) =>
    (Int -> Alg FSet [o]) -> ObservationTable a o -> [[a]] -> [o] -> Maybe (FSet [a])
crfsaDecompose alg ot labels row =
    setDecompose (alg . length $ columnLabels ot) (lesserRows alg ot labels row) row

scrfsaDecompose :: (Ord a, Ord o) =>
    (Int -> Alg FSet [o]) -> ObservationTable a o -> [[a]] -> [o] -> Maybe (FSet [a])
scrfsaDecompose alg ot labels row =
    let
        lesser =
            lesserRows alg ot labels row
        noLesserRow row' row'' =
            lesserRow alg row' row'' `implies` (row'' == row')
        filtered =
            [(u, row') | (u, row') <- lesser, all (noLesserRow row') $ map snd lesser]
    in
    setDecompose (alg . length $ columnLabels ot) filtered row

bolligConsistency :: (Ord a, Ord o) =>
    (Int -> Alg FSet [o]) -> [a] -> Maybe (ObservationTable a o -> Maybe [a])
bolligConsistency alg alph =
    Just $ \ot ->
        let
            rows =
                map snd . Map.toList $ table ot
            cells =
                concat [
                    zip3 (map (a :) $ columnLabels ot) (m1 Map.! a) (m2 Map.! a) |
                        (row1, m1) <- rows,
                        (row2, m2) <- rows,
                        lesserRow alg row1 row2,
                        a <- alph
                ]
            discrepancies =
                map (\(u, _, _) -> u) $ filter (\(_, o1, o2) -> not $ lesserRow alg [o1] [o2]) cells
        in
        listToMaybe discrepancies

randomFSet :: (Ord a) =>
    [a] -> IO (FSet a)
randomFSet as =
    inject . Set.fromList <$> filterM (const $ randomIO) as

nonDetAlg ::
    Alg FSet Bool
nonDetAlg =
    foldr (||) False . Set.toList . unCFree

universalAlg ::
    Alg FSet Bool
universalAlg =
    foldr (&&) True . Set.toList . unCFree
