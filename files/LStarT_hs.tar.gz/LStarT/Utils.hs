module LStarT.Utils
    (
        Enumerable (enumerate),
        implies,
        cartesian,
        adjust,
        removeIndex,
        detachFirst,
        pair,
        prod,
        suffixes,
        nub',
        characteristic,
        collect,
        completeMap,
        average,
        Supported (supp),
        Concrete (concreteApply),
        Alg,
        extend,
        standardDist,
        pointwise,
        uniform,
        randomMap,
        randomFixedSet,
        randomFixedList,
        randomMaxList,
        randomList,
        randomTests
    )
where

import Control.Monad
import Control.Monad.Trans
import Control.Monad.Trans.State
import Data.List
import Data.Maybe
import Data.Functor.Identity
import Data.Set (Set)
import qualified Data.Set as Set
import Data.Map (Map)
import qualified Data.Map as Map
import System.Random

class Enumerable x where
    enumerate ::
        [x]

instance Enumerable () where
    enumerate =
        [()]

instance Enumerable Bool where
    enumerate =
        [False, True]

implies ::
    Bool -> Bool -> Bool
a `implies` b =
    not a || b

cartesian ::
    [a] -> [b] -> [(a, b)]
cartesian as bs =
    [(a, b) | a <- as, b <- bs]

adjust ::
    Int -> (a -> a) -> [a] -> [a]
adjust i f l =
    let
        (l1, l2) =
            splitAt i l
    in
    l1 ++ f (head l2) : tail l2

removeIndex ::
    Int -> [a] -> (a, [a])
removeIndex i l =
    let
        (l1, l2) =
            splitAt i l
    in
    (head l2, l1 ++ tail l2)

detachFirst ::
    (a -> Bool) -> [a] -> Maybe (a, [a])
detachFirst p l =
    case l of
        [] ->
            Nothing
        a : l' ->
            if p a then
                Just (a, l')
            else
                fmap (prod (id, (a :))) $ detachFirst p l'

pair ::
    ((a -> b), (a -> c)) -> a -> (b, c)
pair (f, g) a =
    (f a, g a)

prod ::
    ((a -> b), (c -> d)) -> (a, c) -> (b, d)
prod (f, g) =
    pair (f . fst, g . snd)

suffixes ::
    [a] -> [[a]]
suffixes u =
    case u of
        [] ->
            [[]]
        w@(_ : v) ->
            suffixes v ++ [w]

nub' :: (Ord a) =>
    [a] -> [a]
nub' =
    Set.toList . Set.fromList

characteristic :: (Ord a) =>
    [a] -> Set a -> Map a Bool
characteristic full subset =
    Map.fromList [(a, a `Set.member` subset) | a <- full]

collect :: (Ord a) =>
    [(a, b)] -> Map a [b]
collect =
    foldl' addSingle Map.empty
    where
    addSingle m (a, b) =
        case Map.lookup a m of
            Nothing ->
                Map.insert a [b] m
            Just l ->
                Map.insert a (l ++ [b]) m

completeMap :: (Ord a) =>
    [a] -> b -> Map a b -> Map a b
completeMap keys d m =
    foldl' (\m' a -> Map.insert a d m') m $ keys \\ Map.keys m

average ::
    [Double] -> Double
average l =
    sum l / fromIntegral (length l)

class Supported f where
    supp :: (Ord a) =>
        f a -> [a]

instance Supported Identity where
    supp i =
        [runIdentity i]

class Concrete f where
    concreteApply :: (Ord a) =>
        [a] -> [f a]

instance Concrete Identity where
    concreteApply =
        map Identity

type Alg f a =
    f a -> a

extend :: (Functor f) =>
    Alg f b -> (a -> b) -> f a -> b
extend a f =
    a . fmap f

standardDist :: (Monad t) =>
    Alg t (a -> t b)
standardDist x a =
    join $ fmap (\f -> f a) x

pointwise :: (Functor t) =>
    Alg t x -> Int -> Alg t [x]
pointwise alg n u =
    if n == 0 then
        []
    else
        alg (fmap head u) : pointwise alg (n - 1) (fmap tail u)

uniform ::
    [a] -> State StdGen a
uniform l =
    fmap (l !!) . state $ randomR (0, length l - 1)

randomMap :: (Ord a) =>
    [a] -> State StdGen b -> State StdGen (Map a b)
randomMap as rb =
    Map.fromList . zip as <$> mapM (const rb) as

randomFixedSet ::
    Int -> [a] -> State StdGen [a]
randomFixedSet size l =
    if size == 0 then
        return []
    else
        case l of
            [] ->
                return []
            _ ->
                do
                    i <- state $ randomR (0, length l - 1)
                    let (a, l') = removeIndex i l
                    rest <- randomFixedSet (size - 1) l'
                    return $ a : rest

randomFixedList ::
    Int -> State StdGen a -> State StdGen [a]
randomFixedList size ra =
    sequence $ replicate size ra

randomMaxList ::
    Int -> State StdGen a -> State StdGen [a]
randomMaxList m ra =
    do
        size <- state $ randomR (0, m)
        randomFixedList size ra

randomList ::
    Double -> State StdGen a -> State StdGen [a]
randomList p ra =
    do
        v <- state $ randomR (0.0, 1.0)
        if v <= p then
            return []
        else
            do
                a <- ra
                l <- randomList p ra
                return $ a : l

randomTests :: (Monad s, Eq o) =>
    Int -> State StdGen [a] -> ([a] -> s o) -> ([a] -> s o) -> StateT StdGen s (Maybe [a])
randomTests n sampler l1 l2 =
    if n == 0 then
        return Nothing
    else
        do
            u <- mapStateT (return . runIdentity) sampler
            o1 <- lift $ l1 u
            o2 <- lift $ l2 u
            if o1 == o2 then
                randomTests (n - 1) sampler l1 l2
            else
                return $ Just u
