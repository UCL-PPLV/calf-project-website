{-# LANGUAGE MultiParamTypeClasses #-}

module LStarT.Linear
    (
        mone,
        mmult,
        Semiring (szero, sadd),
        Linear (Linear, fromLinear),
        ladd,
        lscale,
        lminimize,
        Ring (rnegation),
        rminus,
        Field (finverse),
        fdiv,
        gaussianElimination,
        FLinear,
        inSpan,
        randomFLinear,
        linearEval,
        gaussianDecomposeRow
    )
where

import Control.Monad.Trans.State
import Data.List
import Data.Maybe
import qualified Data.Map as Map
import Data.Map (Map)
import System.Random

import LStarT.CFree
import LStarT.LStarT
import LStarT.Utils

mone :: (Monoid m) =>
    m
mone =
    mempty

mmult :: (Monoid m) =>
    m -> m -> m
mmult =
    mappend

class Monoid s => Semiring s where
    szero ::
        s
    sadd ::
        s -> s -> s

newtype Linear s k = Linear {fromLinear :: Map k s}

ladd :: (Semiring s, Ord k, Eq s) =>
    Map k s -> Map k s -> Map k s
ladd m1 m2 =
    let
        update (k, s) m =
            if s == szero then
                m
            else
                case Map.lookup k m of
                    Nothing ->
                        Map.insert k s m
                    Just s' ->
                        let
                            result =
                                sadd s s'
                        in
                        if result == szero then
                            Map.delete k m
                        else
                            Map.insert k result m
    in
    foldr update m1 $ Map.toList m2

lscale :: (Semiring s, Ord k, Eq s) =>
    s -> Map k s -> Map k s
lscale s =
    let
        update (k, s') m =
            let
                result =
                    (mmult s s')
            in
            if result == szero then
                m
            else
                Map.insert k result m
    in
    if s == szero then
        const Map.empty
    else
        foldr update Map.empty . Map.toList

lminimize :: (Semiring s, Ord k, Eq s) =>
    Map k s -> Map k s
lminimize =
    Map.filter (/= szero)

instance (Show k, Show s) => Show (Linear s k) where
    show =
        show . fromLinear

instance (Semiring s, Eq s, Ord k) => Eq (Linear s k) where
    a == b =
        lminimize (fromLinear a) == lminimize (fromLinear b)

instance (Semiring s, Eq s) => Supported (Linear s) where
    supp =
        Map.keys . lminimize . fromLinear

instance (Semiring s, Enumerable s) => Concrete (Linear s) where
    concreteApply =
        let
            possibilities k l =
                [Linear (Map.insert k s (fromLinear l)) | s <- enumerate]
        in
        foldr (\k -> concat . map (possibilities k)) [Linear Map.empty]

class Semiring r => Ring r where
    rnegation ::
        r -> r

rminus :: (Ring r) =>
    r -> r -> r
rminus a b =
    sadd a $ rnegation b

class Ring f => Field f where
    finverse ::
        f -> f

fdiv :: (Field f) =>
    f -> f -> f
fdiv a b =
    mmult a $ finverse b

gaussianElimination :: (Field f, Eq f) =>
    [[f]] -> Maybe [f]
gaussianElimination matrix =
    let
        variables =
            length (matrix !! 0) - 1
        eliminate m n =
            if n < variables then
                case detachFirst ((szero /=) . (!! n)) m of
                    Nothing ->
                        fmap (szero :) $ eliminate m (n + 1)
                    Just (row, m') ->
                        let
                            (d : row') =
                                drop n row
                            value results =
                                foldl' sadd szero $ zipWith mmult row' results
                            s =
                                last row'
                            addResult results =
                                ((s `rminus` value results) `fdiv` d) : results
                            normalise other =
                                [rminus o (mmult (fdiv (other !! n) d) r) | (r, o) <- zip row other]
                        in
                        fmap addResult $ eliminate (map normalise m') (n + 1)
            else
                if all ((szero ==) . (!! variables)) m then
                    Just []
                else
                    Nothing
    in
    eliminate matrix 0

instance (Semiring s, Eq s) => ConstrainedMonad Ord (Linear s) where
    constrainedReturn a =
        Linear $ Map.singleton a mone
    l `constrainedBind` f =
        Linear . foldl' (\m (k, s) -> ladd m . lscale s . fromLinear $ f k) Map.empty . Map.toList . lminimize $ fromLinear l

type FLinear s =
    CFree Ord (Linear s)

inSpan :: (Field f, Eq f, Ord q, Ord r) =>
    (FLinear f q, FLinear f r) -> [(FLinear f q, FLinear f r)] -> Bool
inSpan (fq, fr) fl =
    let
        q =
            fromLinear $ unCFree fq
        r =
            fromLinear $ unCFree fr
        l =
            map (prod (fromLinear . unCFree, fromLinear . unCFree)) fl
        qs =
            nub' $ Map.keys q ++ concat (map (Map.keys . fst) l)
        rs =
            nub' $ Map.keys r ++ concat (map (Map.keys . snd) l)
        convertMap list m =
            map (\a -> Map.findWithDefault szero a m) list
        convertMaps (mq, mr) =
            convertMap qs mq ++ convertMap rs mr
        matrix =
            transpose $ map convertMaps l ++ [convertMap qs q ++ convertMap rs r]
    in
    isJust $ gaussianElimination matrix

randomFLinear :: (Ord a) =>
    [a] -> State StdGen s -> State StdGen (FLinear s a)
randomFLinear as rs =
    inject . Linear <$> randomMap as rs

linearEval :: (Semiring s) =>
    Alg (Linear s) s
linearEval =
    foldl' sadd szero . map (uncurry mmult) . Map.toList . fromLinear

gaussianDecomposeRow :: (Field f, Eq f, Ord a) =>
    ObservationTable a f -> [[a]] -> [f] -> Maybe (CFree Ord (Linear f) [a])
gaussianDecomposeRow ot labels row =
    let
        rows =
            map (getRowU ot) labels
        transposed =
            transpose $ rows ++ [row]
    in
    fmap (inject . Linear . Map.fromList . zip labels) $ gaussianElimination transposed
