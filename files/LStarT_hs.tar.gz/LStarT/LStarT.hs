module LStarT.LStarT
    (
        ObservationTable (ObservationTable, columnLabels, table),
        rowLabels,
        Teacher (Teacher, membership, equivalence, alphabet),
        autTeacher,
        autTeacherT,
        randomTeacher,
        pacTeacher,
        cacheTeacher,
        countTeacher,
        CEHandler (ANGLUIN, MALER_PNUELI, RIVEST_SCHAPIRE),
        Learner (Learner, decomposeRow, consistencyDefect, ceh),
        liftLearner,
        coClosedness,
        noConsistency,
        getRowU,
        getRowL,
        lStarT,
        lStar,
        liftRowU,
        liftRowL,
        findRow,
        findRow',
        lazyDecomposeRow,
        lazyConsistencyDefect,
        plainConsistencyDefect
    )
where

import Data.List
import Data.Maybe
import Control.Monad
import Control.Monad.Trans.Class
import Control.Monad.Trans.State
import Data.Functor.Identity
import Data.Map (Map)
import qualified Data.Map as Map
import System.Random

import LStarT.Automaton
import LStarT.Utils

data ObservationTable a o = ObservationTable {
    columnLabels ::
        [[a]],
    table ::
        Map [a] ([o], Map a [o])
} deriving Show

rowLabels ::
    ObservationTable a o -> [[a]]
rowLabels ot =
    Map.keys $ table ot

data Teacher s a o q = Teacher {
    membership ::
        [a] -> s o,
    equivalence ::
        Aut a o q -> s (Maybe [a]),
    alphabet ::
        [a]
}

autTeacher :: (Monad s, Eq q, Eq r, Eq o) =>
    [a] -> Aut a o q -> Teacher s a o r
autTeacher alph x =
    let
        m =
            return . autLang x
        e =
            return . bisim alph x
    in
    Teacher {membership = m, equivalence = e, alphabet = alph}

autTeacherT :: (Monad s, Eq o) =>
    ((t q, t r) -> [(t q, t r)] -> Bool) -> [a] -> Aut a o (t q) -> Teacher s a o (t r)
autTeacherT elemt alph x =
    let
        m =
            return . autLang x
        e =
            return . bisimT elemt alph x
    in
    Teacher {membership = m, equivalence = e, alphabet = alph}

randomTeacher :: (Monad s, Eq o) =>
    Int -> State StdGen [a] -> [a] -> ([a] -> s o) -> Teacher (StateT StdGen s) a o q
randomTeacher tests sampler alph l =
    Teacher {
        membership =
            lift . l,
        equivalence =
            \x -> randomTests tests sampler l $ return . autLang x,
        alphabet =
            alph
    }

pacTeacher :: (Monad s, Eq o) =>
    Double -> Double -> State StdGen [a] -> [a] -> ([a] -> s o) -> Teacher (StateT (Int, StdGen) s) a o q
pacTeacher acc conf sampler alph l =
    let
        tests i =
            ceiling $ (log (1.0 / conf) + (log 2.0) * (fromIntegral i + 1.0)) / acc
        e x =
            do
                (i, g) <- get
                (u, g) <- lift $ runStateT (randomTests (tests i) sampler l $ return . autLang x) g
                put (i + 1, g)
                return u
    in
    Teacher {membership = lift . l, equivalence = e, alphabet = alph}

cacheTeacher :: (Monad s, Ord a) =>
    Teacher s a o q -> Teacher (StateT (Map [a] o) s) a o q
cacheTeacher t =
    let
        m u =
            do
                cache <- get
                if u `Map.member` cache then
                    return $ cache Map.! u
                else do
                    o <- lift (membership t u)
                    put (Map.insert u o cache)
                    return o
    in
    Teacher {membership = m, equivalence = lift . equivalence t, alphabet = alphabet t}

countTeacher :: (Monad s) =>
    Teacher s a o q -> Teacher (StateT (Int, Int) s) a o q
countTeacher t =
    let
        m u =
            do
                modify (\(a, b) -> (a + 1, b))
                lift (membership t u)
        e x =
            do
                modify (\(a, b) -> (a, b + 1))
                lift (equivalence t x)
    in
    Teacher {membership = m, equivalence = e, alphabet = alphabet t}

data CEHandler = ANGLUIN | MALER_PNUELI | RIVEST_SCHAPIRE

data Learner t a o = Learner {
    decomposeRow ::
        ObservationTable a o -> [[a]] -> [o] -> Maybe (t [a]),
    consistencyDefect ::
        Maybe (ObservationTable a o -> Maybe [a]),
    ceh ::
        CEHandler
}

liftLearner :: (Monad t) =>
    Learner Identity a o -> Learner t a o
liftLearner l =
    l {decomposeRow = \ot labels row -> return . runIdentity <$> decomposeRow l ot labels row}

coClosedness ::
    Maybe (ObservationTable a o -> Maybe [a])
coClosedness =
    Nothing

noConsistency ::
    Maybe (ObservationTable a o -> Maybe [a])
noConsistency =
    Just $ const Nothing

getRowU :: (Ord a) =>
    ObservationTable a o -> [a] -> [o]
getRowU ot u =
    fst $ table ot Map.! u

getRowL :: (Ord a) =>
    ObservationTable a o -> [a] -> a -> [o]
getRowL ot u a =
    snd (table ot Map.! u) Map.! a

addRow :: (Monad s, Ord a) =>
    Teacher s a o q -> ObservationTable a o -> [a] -> s (ObservationTable a o)
addRow t ot u =
    if Map.member u (table ot) then
        return ot
    else
        do
            let alph = alphabet t
            row <- createRow [] (columnLabels ot)
            arows <- sequence $ map (\a -> createRow [a] (columnLabels ot)) alph
            let m = Map.fromList $ zip alph arows
            return $ ot {table = Map.insert u (row, m) $ table ot}
            where
            createRow p =
                mapM (\v -> membership t $ u ++ p ++ v)

addColumn :: (Monad s, Ord a) =>
    Teacher s a o q -> ObservationTable a o -> [a] -> s (ObservationTable a o)
addColumn t ot v =
    if v `elem` columnLabels ot then
        return ot
    else
        do
            table <- Map.traverseWithKey addCells $ table ot
            return $ ot {table = table, columnLabels = columnLabels ot ++ [v]}
            where
            addCells u (row, m) =
                do
                    o <- membership t (u ++ v)
                    m <- foldM addCell m (Map.keys m)
                    return (row ++ [o], m)
                    where
                    addCell m a =
                        do
                            o <- membership t (u ++ [a] ++ v)
                            return $ Map.insert a ((m Map.! a) ++ [o]) m

distortedMembership :: (Monad s, Monad t, Supported t, Ord a) =>
    Alg t o -> Teacher s a o q -> Aut a o (t [a]) -> [a] -> [a] -> s o
distortedMembership alg t x u v =
    do
        let
            w =
                do
                    u' <- reach x u
                    return $ u' ++ v
            associate z =
                do
                    o <- membership t z
                    return (z, o)
        assocs <- mapM associate $ supp w
        return $ extend alg ((Map.!) (Map.fromList assocs)) w

reverseTable :: (Ord a) =>
    [a] -> ObservationTable a o -> ObservationTable a o
reverseTable alph ot =
    let
        list =
            Map.toList $ table ot
        newColumnLabels =
            map (reverse . fst) list
        upperCells =
            transpose $ map (fst . snd) list
        lowerCells a =
            transpose $ map ((Map.! a) . snd . snd) list
        lowerMaps =
            foldr (\a -> zipWith (Map.insert a) (lowerCells a)) (repeat Map.empty) alph
        newRowLabels =
            map reverse $ columnLabels ot
        newTable =
            Map.fromList $ zip newRowLabels $ zip upperCells lowerMaps
    in
    ObservationTable {columnLabels = newColumnLabels, table = newTable}

prepareTable :: (Monad s, Ord a) =>
    Teacher s a o q -> Learner t a o -> ObservationTable a o -> s (Bool, ObservationTable a o)
prepareTable t l ot =
    do
        let
            alph =
                alphabet t
            closednessDefect u row =
                if isJust (decomposeRow l ot (rowLabels ot) row) then
                    Nothing
                else
                    Just u
            defectMap =
                Map.mapWithKey (\u -> Map.mapWithKey (\a -> closednessDefect (u ++ [a])) . snd) $ table ot
            foldMaybe m1 m2 =
                if isJust m1 then
                    m1
                else
                    m2
        case Map.foldr foldMaybe Nothing (Map.map (Map.foldr foldMaybe Nothing) defectMap) of
            Nothing ->
                case consistencyDefect l of
                    Nothing ->
                        do
                            (changed, ot) <- prepareTable (t {membership = membership t . reverse})
                                (l {consistencyDefect = noConsistency}) $ reverseTable alph ot
                            if changed then do
                                (_, ot) <- prepareTable t l $ reverseTable alph ot
                                return (True, ot)
                            else
                                return (False, reverseTable alph ot)
                    Just fixer ->
                        case fixer ot of
                            Nothing ->
                                return (False, ot)
                            Just cd ->
                                do
                                    ot <- addColumn t ot cd
                                    (_, ot) <- prepareTable t l ot
                                    return (True, ot)
            Just cd ->
                do
                    ot <- addRow t ot cd
                    (_, ot) <- prepareTable t l ot
                    return (True, ot)

handleCE :: (Monad s, Monad t, Supported t, Ord a, Eq o) =>
    CEHandler -> Alg t o -> Teacher s a o (t [a]) -> ObservationTable a o -> Aut a o (t [a]) -> [a] -> s (ObservationTable a o)
handleCE handler alg t ot hyp ce =
    case handler of
        ANGLUIN ->
            foldM (addRow t) ot $ inits ce
        MALER_PNUELI ->
            foldM (addColumn t) ot $ suffixes ce
        RIVEST_SCHAPIRE ->
            do
                actual <- membership t ce
                base <- distortedMembership alg t hyp [] ce
                if base == actual then
                    let
                        search pre x post =
                            if length x > 1 then
                                do
                                    let
                                        (u, v) =
                                            splitAt (length x `div` 2) x
                                        start =
                                            pre ++ u
                                        end =
                                            v ++ post
                                    o <- distortedMembership alg t hyp start end
                                    if o == actual then
                                        search start v post
                                    else
                                        search pre u end
                            else
                                addColumn t ot post
                    in
                    search [] ce []
                else
                    addColumn t ot ce

lStarT :: (Monad s, Monad t, Supported t, Ord a, Eq o) =>
    Alg t (a -> t [a]) -> Alg t o -> Teacher s a o (t [a]) -> Learner t a o -> s (SAut t a o [a])
lStarT dist alg t l =
    do
        let ot = ObservationTable {columnLabels = [], table = Map.empty}
        ot <- addRow t ot []
        ot <- addColumn t ot []
        lStarT' ot
        where
        lStarT' ot =
            do
                (_, ot) <- prepareTable t l ot
                let
                    hyp =
                        hypothesis (alphabet t) l ot
                    d =
                        det dist alg hyp
                mce <- equivalence t d
                case mce of
                    Nothing ->
                        return hyp
                    Just ce ->
                        do
                            ot <- handleCE (ceh l) alg t ot d ce
                            lStarT' ot

lStar :: (Monad s, Ord a, Eq o) =>
    Teacher s a o (Identity [a]) -> Learner Identity a o -> s (SAut Identity a o [a])
lStar =
    lStarT runIdentity runIdentity

liftRowU :: (Functor t, Ord a) =>
    (Int -> Alg t [o]) -> ObservationTable a o -> t [a] -> [o]
liftRowU alg ot =
    extend (alg . length $ columnLabels ot) $ getRowU ot

liftRowL :: (Functor t, Ord a) =>
    (Int -> Alg t [o]) -> ObservationTable a o -> t [a] -> a -> [o]
liftRowL alg ot u a =
    extend (alg . length $ columnLabels ot) (\u' -> getRowL ot u' a) u

hypothesis :: (Monad t, Ord a) =>
    [a] -> Learner t a o -> ObservationTable a o -> SAut t a o [a]
hypothesis alph l ot =
    let
        eliminateStates todo states =
            case todo of
                [] ->
                    states
                u : todo' ->
                    case decomposeRow l ot (states ++ todo') (getRowU ot u) of
                        Nothing ->
                            eliminateStates todo' (u : states)
                        Just v ->
                            eliminateStates todo' states
        states =
            eliminateStates (rowLabels ot) []
        sinitial =
            fromJust $ decomposeRow l ot states $ getRowU ot []
        sdelta =
            Map.fromList [
                (q,
                    Map.fromList [
                        (a, fromJust $ decomposeRow l ot states $ getRowL ot q a) |
                            a <- alph
                    ]
                ) |
                    q <- states
            ]
        sout =
            Map.fromList [(q, head $ getRowU ot q) | q <- states]
    in
    SAut {sinitial = sinitial, sdelta = sdelta, sout = sout}

findRow :: (Ord a, Eq o) =>
    ObservationTable a o -> [[a]] -> [o] -> Maybe (Identity [a])
findRow ot labels row =
    listToMaybe [Identity u | (u, (row', _)) <- Map.toList $ table ot, row' == row, u `elem` labels]

findRow' :: (Ord a, Eq o) =>
    ObservationTable a o -> [[a]] -> [o] -> Maybe (Identity [a])
findRow' ot labels row =
    listToMaybe [Identity u | u <- labels, let row' = getRowU ot u, row' == row]

lazyDecomposeRow :: (Functor t, Concrete t, Ord a, Eq o) =>
    (Int -> Alg t [o]) -> ObservationTable a o -> [[a]] -> [o] -> Maybe (t [a])
lazyDecomposeRow alg ot labels row =
    listToMaybe [u | u <- concreteApply labels, liftRowU alg ot u == row]

lazyConsistencyDefect :: (Functor t, Concrete t, Ord a, Eq o) =>
    (Int -> Alg t [o]) -> [a] -> Maybe (ObservationTable a o -> Maybe [a])
lazyConsistencyDefect alg alph =
    Just $ \ot ->
        let
            rows =
                [(u, liftRowU alg ot u) | u <- concreteApply $ rowLabels ot]
            cells =
                concat [
                    zip3 (map (a :) $ columnLabels ot) (liftRowL alg ot u1 a) (liftRowL alg ot u2 a) |
                        (u1, row1) <- rows,
                        (u2, row2) <- rows,
                        row1 == row2,
                        a <- alph
                ]
            discrepancies =
                map (\(u, _, _) -> u) $ filter (\(_, o1, o2) -> o1 /= o2) cells
        in
        listToMaybe discrepancies

plainConsistencyDefect :: (Ord a, Eq o) =>
    [a] -> Maybe(ObservationTable a o -> Maybe [a])
plainConsistencyDefect =
    lazyConsistencyDefect $ const runIdentity
