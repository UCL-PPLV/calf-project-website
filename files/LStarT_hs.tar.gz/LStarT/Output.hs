{-# LANGUAGE FlexibleInstances #-}

module LStarT.Output () where

import Control.Monad.Writer
import Data.Functor.Identity

import LStarT.Utils

instance Supported (Writer w) where
    supp w =
        [fst $ runWriter w]

instance Enumerable w => Concrete (Writer w) where
    concreteApply l =
        [WriterT (Identity (a, w)) | a <- l, w <- enumerate]
