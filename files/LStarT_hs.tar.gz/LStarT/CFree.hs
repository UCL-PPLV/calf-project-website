{-# LANGUAGE GADTs #-}
{-# LANGUAGE ConstraintKinds #-}
{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}

module LStarT.CFree
    (
        CFree (Return, Bind),
        inject,
        ConstrainedMonad (constrainedReturn, constrainedBind),
        unCFree,
        optimiseDist
    )
where

import Control.Monad
import qualified Data.Set as Set
import Data.Set (Set)
import qualified Data.Map as Map
import Data.Map (Map)

import LStarT.Utils

data CFree c f a where
    Return ::
        a -> CFree c f a
    Bind :: (c b) =>
        f b -> (b -> CFree c f a) -> CFree c f a

inject :: (c a) =>
    f a -> CFree c f a
inject s =
    Bind s Return

instance Monad (CFree c f) where
    return =
        Return
    f >>= g =
        case f of
            Return a ->
                g a
            Bind s h ->
                s `Bind` (h >=> g)

instance Applicative (CFree c f) where
    pure =
        return
    (<*>) =
        ap

instance Functor (CFree c f) where
    fmap =
        liftM

instance (Concrete f) => Concrete (CFree Ord f) where
    concreteApply =
        map inject . concreteApply

class ConstrainedMonad c m | m -> c where
    constrainedReturn :: (c a) =>
        a -> m a
    constrainedBind :: (c a, c b) =>
        m b -> (b -> m a) -> m a

unCFree :: (ConstrainedMonad c m, c a) =>
    CFree c m a -> m a
unCFree f =
    case f of
        Return a ->
            constrainedReturn a
        Bind s g ->
            s `constrainedBind` (unCFree . g)

instance (Eq (m a), ConstrainedMonad c m, c a) => Eq (CFree c m a) where
    a == b =
        unCFree a == unCFree b

instance (Show (m a), ConstrainedMonad c m, c a) => Show (CFree c m a) where
    show =
        show . unCFree

instance (Supported m, ConstrainedMonad Ord m) => Supported (CFree Ord m) where
    supp =
        supp . unCFree

optimiseDist :: (ConstrainedMonad c m, c b) =>
    Alg (CFree c m) (a -> CFree c m b) -> Alg (CFree c m) (a -> CFree c m b)
optimiseDist dist x =
    inject . unCFree . dist x
