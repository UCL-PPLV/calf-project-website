module LStarT.Experiment
    (
        LearnExperiment,
        newLearnExperiment,
        saveLearnExperiment,
        addLearnExperimentAt,
        addLearnExperiment,
        writeLearnExperiment,
        lastLearnExperimentResults,
        runExperiments,
        runExperimentsStrict,
        runExperimentsLoose
    )
where

import Control.Monad.Trans.State
import Data.Functor.Identity
import Data.Map (Map)
import qualified Data.Map as Map
import System.IO
import System.Random
import System.Directory

import LStarT.LStarT
import LStarT.Automaton
import LStarT.Utils

data Experiment = Experiment {
    currentExperiment ::
        Int,
    experimentLabels ::
        [String],
    experiments ::
        [[Double]]
}

newExperiment ::
    Experiment
newExperiment =
    Experiment {currentExperiment = 0, experimentLabels = [], experiments = [[]]}

saveExperiment ::
    String -> Experiment -> Experiment
saveExperiment label e =
    Experiment {
        experimentLabels =
            experimentLabels e ++ [label],
        currentExperiment =
            currentExperiment e + 1,
        experiments =
            experiments e ++ [[]]
    }

addExperimentAt ::
    Int -> Double -> Experiment -> Experiment
addExperimentAt i v e =
    e {experiments = adjust i (\l -> l ++ [v]) $ experiments e}

addExperiment ::
    Double -> Experiment -> Experiment
addExperiment v e =
    addExperimentAt (currentExperiment e) v e

lastExperimentResult ::
    Experiment -> Double
lastExperimentResult e =
    last $ experiments e !! currentExperiment e

writeExperiment ::
    Experiment -> FilePath -> IO ()
writeExperiment e path =
    do
        handle <- openFile path WriteMode
        sequence_ $ zipWith (\label values -> hPutStrLn handle $ label ++ " " ++ show (average values)) (experimentLabels e) (experiments e)
        hClose handle

data LearnExperiment = LearnExperiment {
    mqExperiment ::
        Experiment,
    eqExperiment ::
        Experiment,
    sizeExperiment ::
        Experiment
}

newLearnExperiment ::
    LearnExperiment
newLearnExperiment =
    LearnExperiment {mqExperiment = newExperiment, eqExperiment = newExperiment, sizeExperiment = newExperiment}

saveLearnExperiment ::
    String -> LearnExperiment -> LearnExperiment
saveLearnExperiment label e =
    LearnExperiment {
        mqExperiment =
            saveExperiment label $ mqExperiment e,
        eqExperiment =
            saveExperiment label $ eqExperiment e,
        sizeExperiment =
            saveExperiment label $ sizeExperiment e
    }

addLearnExperimentAt ::
    Int -> Int -> Int -> Int -> LearnExperiment -> LearnExperiment
addLearnExperimentAt i mqs eqs size e =
    LearnExperiment {
        mqExperiment =
            addExperimentAt i (fromIntegral mqs) $ mqExperiment e,
        eqExperiment =
            addExperimentAt i (fromIntegral eqs) $ eqExperiment e,
        sizeExperiment =
            addExperimentAt i (fromIntegral size) $ sizeExperiment e
    }

addLearnExperiment ::
    Int -> Int -> Int -> LearnExperiment -> LearnExperiment
addLearnExperiment mqs eqs size e =
    LearnExperiment {
        mqExperiment =
            addExperiment (fromIntegral mqs) $ mqExperiment e,
        eqExperiment =
            addExperiment (fromIntegral eqs) $ eqExperiment e,
        sizeExperiment =
            addExperiment (fromIntegral size) $ sizeExperiment e
    }

writeLearnExperiment ::
    LearnExperiment -> FilePath -> IO ()
writeLearnExperiment e path =
    do
        writeExperiment (mqExperiment e) $ path ++ "_mq.dat"
        writeExperiment (eqExperiment e) $ path ++ "_eq.dat"
        writeExperiment (sizeExperiment e) $ path ++ "_size.dat"

lastLearnExperimentResults ::
    LearnExperiment -> (Double, Double, Double)
lastLearnExperimentResults e =
    (lastExperimentResult (mqExperiment e), lastExperimentResult (eqExperiment e), lastExperimentResult (sizeExperiment e))

runExperiment :: (Monad s, Monad t, Supported t, Ord a, Eq o) =>
    Alg t (a -> t [a]) -> Alg t o -> Teacher s a o (t [a]) -> Learner t a o -> LearnExperiment -> s LearnExperiment
runExperiment dist alg t l e =
    do
        ((result, _), (mqs, eqs)) <- runStateT (runStateT (lStarT dist alg (cacheTeacher $ countTeacher t) l) Map.empty) (0, 0)
        return $ addLearnExperiment mqs eqs (autSize result) e

runExperiments :: (Monad t, Supported t, Ord a, Eq o) =>
    Alg t (a -> t [a]) -> Alg t o -> (Aut a o (t q) -> Teacher (State StdGen) a o (t [a])) -> (Int -> State StdGen (Aut a o (t q))) -> Int -> Int -> Int -> Int -> String -> [(String, Learner t a o)] -> IO ()
runExperiments dist alg t generator start end step iterations dir learners =
    do
        putStrLn dir
        createDirectoryIfMissing True dir
        runExperiments' 0 start 0 $ zip learners $ repeat newLearnExperiment
    where
    runExperiments' seed size i experimenters =
        if size > end then
            do
                putStrLn "Writing results"
                mapM_ (\((n, _), e) -> writeLearnExperiment e (dir ++ n)) experimenters
        else
            if i == iterations then
                do
                    let results = map (prod (id, saveLearnExperiment $ show size)) experimenters
                    runExperiments' seed (size + step) 0 results
            else
                do
                    putStrLn $ "Size " ++ show size ++ "/" ++ show end ++ " (" ++ show step ++ "), experiment " ++ show (i + 1) ++ "/" ++ show iterations
                    let
                        (aut, stdGen) =
                            runState (generator size) $ mkStdGen seed
                        results =
                            evalState (mapM (
                                \((n, l), e) ->
                                    do
                                        e' <- runExperiment dist alg (t aut) l e
                                        return ((n, l), e')
                            ) experimenters) stdGen
                    print $ map lastLearnExperimentResults $ map snd results
                    runExperiments' (seed + 1) size (i + 1) results

runExperimentsStrict :: (Monad t, Supported t, Ord a, Eq o) =>
    Alg t (a -> t [a]) -> Alg t o -> ((t q, t [a]) -> [(t q, t [a])] -> Bool) -> [a] -> (Int -> State StdGen (Aut a o (t q))) -> Int -> Int -> Int -> Int -> String -> [(String, Learner t a o)] -> IO ()
runExperimentsStrict dist alg elemt alph =
    runExperiments dist alg $ autTeacherT elemt alph

runExperimentsLoose :: (Monad t, Supported t, Ord a, Eq o) =>
    Alg t (a -> t [a]) -> Alg t o -> Int -> Double -> [a] -> (Int -> State StdGen (Aut a o (t q))) -> Int -> Int -> Int -> Int -> String -> [(String, Learner t a o)] -> IO ()
runExperimentsLoose dist alg tests p alph =
    runExperiments dist alg $ randomTeacher tests (randomList p $ uniform alph) alph . (\l -> Identity . l) . autLang
