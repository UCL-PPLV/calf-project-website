# L\*T

L\*T optimizes the L\* algorithm due to Dana Angluin by learning automata
enriched with side-effects given by a monad.

## Building

To build the code, run a Haskell compiler on the `.hs` files found in the
`LStarT` directory, as well as the ones in the main directory.

## Running

L\*T should be seen as a library. However, one may run the set of examples
given in `examples.hs` or the experiments in `experiments.hs`.
