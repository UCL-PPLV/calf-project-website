import Control.Monad.Trans.State
import Data.List
import Data.Functor.Identity
import Data.Set (Set)
import qualified Data.Set as Set
import Data.Map (Map)
import qualified Data.Map as Map
import System.Random

import LStarT.Experiment
import LStarT.Automaton
import LStarT.LStarT
import LStarT.CFree
import LStarT.Linear
import LStarT.NonDeterminism
import LStarT.Utils

looseIterations ::
    Int
looseIterations =
    10000

looseStop ::
    Double
looseStop =
    0.08

fieldSize ::
    Int
fieldSize =
    5

newtype ModField =
    ModField {
        fromMod :: Int
    }

instance Eq ModField where
    (ModField a) == (ModField b) =
        a == b

instance Show ModField where
    show (ModField a) =
        show a

instance Ord ModField where
    (ModField a) `compare` (ModField b) =
        a `compare` b

instance Enumerable ModField where
    enumerate =
        [ModField i | i <- [0 .. fieldSize - 1]]

instance Monoid ModField where
    mempty =
        ModField 1
    mappend (ModField a) (ModField b) =
        ModField ((a * b) `mod` fieldSize)

instance Semiring ModField where
    szero =
        ModField 0
    sadd (ModField a) (ModField b) =
        ModField ((a + b) `mod` fieldSize)

instance Ring ModField where
    rnegation (ModField a) =
        ModField $ fieldSize - a

instance Field ModField where
    finverse =
        foldl' mmult mone . replicate (fieldSize - 2)

randomModField ::
    State StdGen ModField
randomModField =
    uniform enumerate

randomModFieldNonZero ::
    State StdGen ModField
randomModFieldNonZero =
    uniform $ delete szero enumerate

angluinLearner :: (Ord a, Eq o) =>
    [a] -> Learner Identity a o
angluinLearner alph =
    Learner {
        decomposeRow =
            findRow,
        consistencyDefect =
            plainConsistencyDefect alph,
        ceh =
            ANGLUIN
    }

mpLearner :: (Ord a, Eq o) =>
    Learner Identity a o
mpLearner =
    Learner {
        decomposeRow =
            findRow,
        consistencyDefect =
            noConsistency,
        ceh =
            MALER_PNUELI
    }

rsLearner :: (Ord a, Eq o) =>
    Learner Identity a o
rsLearner =
    Learner {
        decomposeRow =
            findRow,
        consistencyDefect =
            noConsistency,
        ceh =
            RIVEST_SCHAPIRE
    }

wangluinLearner :: (Ord a) =>
    Learner (FLinear ModField) a ModField
wangluinLearner =
    Learner {
        decomposeRow =
            gaussianDecomposeRow,
        consistencyDefect =
            coClosedness,
        ceh =
            ANGLUIN
    }

wmpLearner :: (Ord a) =>
    Learner (FLinear ModField) a ModField
wmpLearner =
    Learner {
        decomposeRow =
            gaussianDecomposeRow,
        consistencyDefect =
            coClosedness,
        ceh =
            MALER_PNUELI
    }

wmpmLearner :: (Ord a) =>
    Learner (FLinear ModField) a ModField
wmpmLearner =
    Learner {
        decomposeRow =
            gaussianDecomposeRow,
        consistencyDefect =
            noConsistency,
        ceh =
            MALER_PNUELI
    }

wrsLearner :: (Ord a) =>
    Learner (FLinear ModField) a ModField
wrsLearner =
    Learner {
        decomposeRow =
            gaussianDecomposeRow,
        consistencyDefect =
            coClosedness,
        ceh =
            RIVEST_SCHAPIRE
    }

wrsmLearner :: (Ord a) =>
    Learner (FLinear ModField) a ModField
wrsmLearner =
    Learner {
        decomposeRow =
            gaussianDecomposeRow,
        consistencyDefect =
            noConsistency,
        ceh =
            RIVEST_SCHAPIRE
    }

nmpLearner :: (Ord a) =>
    (Int -> FSet [Bool] -> [Bool]) -> [a] -> Learner FSet a Bool
nmpLearner rowAlg alph =
    Learner {
        decomposeRow =
            scrfsaDecompose rowAlg,
        consistencyDefect =
            bolligConsistency rowAlg alph,
        ceh =
            MALER_PNUELI
    }

nmpmLearner :: (Ord a) =>
    (Int -> FSet [Bool] -> [Bool]) -> Learner FSet a Bool
nmpmLearner rowAlg =
    Learner {
        decomposeRow =
            scrfsaDecompose rowAlg,
        consistencyDefect =
            noConsistency,
        ceh =
            MALER_PNUELI
    }

nrsLearner :: (Ord a) =>
    (Int -> FSet [Bool] -> [Bool]) -> [a] -> Learner FSet a Bool
nrsLearner rowAlg alph =
    Learner {
        decomposeRow =
            scrfsaDecompose rowAlg,
        consistencyDefect =
            bolligConsistency rowAlg alph,
        ceh =
            RIVEST_SCHAPIRE
    }

nrsmLearner :: (Ord a) =>
    (Int -> FSet [Bool] -> [Bool]) -> Learner FSet a Bool
nrsmLearner rowAlg =
    Learner {
        decomposeRow =
            scrfsaDecompose rowAlg,
        consistencyDefect =
            noConsistency,
        ceh =
            RIVEST_SCHAPIRE
    }

runDFAExperiments ::
    IO ()
runDFAExperiments =
    let
        dist =
            runIdentity
        alg =
            runIdentity
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
            in
            do
                saut <- randomSAut alph (uniform [False, True]) states $ Identity <$> uniform states
                return $ det dist alg saut
    in
    do
        runExperimentsStrict dist alg elem alph genAut 20 200 20 100 "experiments/dfa/"
            [
                ("lstar", angluinLearner alph),
                ("lstarMP", mpLearner),
                ("lstarRS", rsLearner)
            ]
        runExperimentsLoose dist alg looseIterations looseStop alph genAut 20 200 20 100 "experiments/dfa_loose/"
            [
                ("lstar", angluinLearner alph),
                ("lstarMP", mpLearner),
                ("lstarRS", rsLearner)
            ]

runNFAExperiments ::
    IO ()
runNFAExperiments =
    let
        dist =
            standardDist
        alg =
            nonDetAlg
        rowAlg =
            pointwise alg
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
                randomOutput =
                    do
                        f <- randomFixedSet (round $ (fromIntegral n) * 0.5) states
                        return $ characteristic states $ Set.fromList f
                randomTransitions =
                    do
                        l <- sequence [randomFixedSet (round $ (fromIntegral n) * 1.25) (cartesian states states) | _ <- alph]
                        let reordered = map (\(a, (q1, q2)) -> (q1, (a, q2))) . concat $ zipWith (\a pairs -> zip (repeat a) pairs) alph l
                        return $ Map.map (Map.map (inject . Set.fromList) . completeMap alph [] . collect) $ completeMap states [] $ collect reordered
            in
            do
                saut <- randomSAutByMap (return . inject $ Set.singleton 1) randomTransitions randomOutput
                return $ det (optimiseDist dist) alg saut
    in
    do
        runExperimentsStrict (optimiseDist dist) alg elem alph genAut 4 16 4 100 "experiments/nfa/"
            [
                ("lstar", liftLearner $ angluinLearner alph),
                ("lstarMP", liftLearner mpLearner),
                ("lstarRS", liftLearner rsLearner),
                ("nlstarMP", nmpLearner rowAlg alph),
                ("nlstarMPNC", nmpmLearner rowAlg),
                ("nlstarRS", nrsLearner rowAlg alph),
                ("nlstarRSNC", nrsmLearner rowAlg)
            ]
        runExperimentsLoose (optimiseDist dist) alg looseIterations looseStop alph genAut 4 16 4 100 "experiments/nfa_loose/"
            [
                ("lstar", liftLearner $ angluinLearner alph),
                ("lstarMP", liftLearner mpLearner),
                ("lstarRS", liftLearner rsLearner),
                ("nlstarMP", nmpLearner rowAlg alph),
                ("nlstarMPNC", nmpmLearner rowAlg),
                ("nlstarRS", nrsLearner rowAlg alph),
                ("nlstarRSNC", nrsmLearner rowAlg)
            ]

runWFAonMooreExperiments ::
    IO ()
runWFAonMooreExperiments =
    let
        dist =
            standardDist
        alg =
            linearEval . unCFree
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
            in
            do
                saut <- randomSAut alph randomModField states $ return <$> uniform states
                return $ det (optimiseDist dist) alg saut
    in
    do
        runExperimentsStrict (optimiseDist dist) alg elem alph genAut 5 50 5 100 "experiments/wfa/"
            [
                ("vangluinDFA", liftLearner $ angluinLearner alph),
                ("angluinDFA", wangluinLearner),
                ("mpDFA", wmpLearner),
                ("mpmDFA", wmpmLearner),
                ("rsDFA", wrsLearner),
                ("rsmDFA", wrsmLearner)
            ]
        runExperimentsLoose (optimiseDist dist) alg looseIterations looseStop alph genAut 5 50 5 100 "experiments/wfa_loose/"
            [
                ("vangluinDFA", liftLearner $ angluinLearner alph),
                ("angluinDFA", wangluinLearner),
                ("mpDFA", wmpLearner),
                ("mpmDFA", wmpmLearner),
                ("rsDFA", wrsLearner),
                ("rsmDFA", wrsmLearner)
            ]

runWFAVanillaExperiments ::
    IO ()
runWFAVanillaExperiments =
    let
        dist =
            standardDist
        alg =
            linearEval . unCFree
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
            in
            do
                saut <- randomSAut alph randomModField states $ (inject . Linear <$> randomMap states randomModField)
                return $ det (optimiseDist dist) alg saut
    in
    do
        runExperimentsStrict (optimiseDist dist) alg elem alph genAut 1 4 1 100 "experiments/wfa/"
            [
                ("vangluin", liftLearner $ angluinLearner alph),
                ("vmp", liftLearner mpLearner),
                ("vrs", liftLearner rsLearner),
                ("weighted", wangluinLearner),
                ("weightedmp", wmpLearner),
                ("weightedrs", wrsLearner)
            ]
        runExperimentsLoose (optimiseDist dist) alg looseIterations looseStop alph genAut 1 4 1 100 "experiments/wfa_loose/"
            [
                ("vangluin", liftLearner $ angluinLearner alph),
                ("vmp", liftLearner mpLearner),
                ("vrs", liftLearner rsLearner),
                ("weighted", wangluinLearner),
                ("weightedmp", wmpLearner),
                ("weightedrs", wrsLearner)
            ]

runWFAExperiments ::
    IO ()
runWFAExperiments =
    let
        dist =
            standardDist
        alg =
            linearEval . unCFree
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
            in
            do
                saut <- randomSAut alph randomModField states $ (inject . Linear <$> randomMap states randomModField)
                return $ det (optimiseDist dist) alg saut
    in
    do
        runExperimentsStrict (optimiseDist dist) alg inSpan alph genAut 5 30 5 100 "experiments/wfa/"
            [
                ("angluin", wangluinLearner),
                ("mp", wmpLearner),
                ("mpm", wmpmLearner),
                ("rs", wrsLearner),
                ("rsm", wrsmLearner)
            ]
        runExperimentsLoose (optimiseDist dist) alg looseIterations looseStop alph genAut 5 30 5 100 "experiments/wfa_loose/"
            [
                ("angluin", wangluinLearner),
                ("mp", wmpLearner),
                ("mpm", wmpmLearner),
                ("rs", wrsLearner),
                ("rsm", wrsmLearner)
            ]

runWFASparseExperiments ::
    IO ()
runWFASparseExperiments =
    let
        dist =
            standardDist
        alg =
            linearEval . unCFree
        alph =
            [1 .. 3]
        genAut n =
            let
                states =
                    [1 .. n]
                randomOutput =
                    randomMap states randomModField
                addWeight (q1, q2) =
                    do
                        w <- randomModFieldNonZero
                        return (q1, (q2, w))
                randomTransitions =
                    do
                        l <- sequence [randomFixedSet (round $ (fromIntegral n) * 1.25) (cartesian states states) | _ <- alph]
                        weighted <- mapM (mapM addWeight) l
                        let reordered = map (\(a, (q1, q2)) -> (q1, (a, q2))) . concat $ zipWith (\a pairs -> zip (repeat a) pairs) alph weighted
                        return $ Map.map (Map.map (inject . Linear . Map.fromList) . completeMap alph [] . collect) $ completeMap states [] $ collect reordered
            in
            do
                saut <- randomSAutByMap (return . inject . Linear $ Map.singleton 1 mone) randomTransitions randomOutput
                return $ det (optimiseDist dist) alg saut
    in
    do
        runExperimentsStrict (optimiseDist dist) alg inSpan alph genAut 4 32 4 100 "experiments/wfa_sparse/"
            [
                ("angluin", wangluinLearner),
                ("mp", wmpLearner),
                ("mpm", wmpmLearner),
                ("rs", wrsLearner),
                ("rsm", wrsmLearner)
            ]
        runExperimentsLoose (optimiseDist dist) alg looseIterations looseStop alph genAut 4 32 4 100 "experiments/wfa_sparse_loose/"
            [
                ("angluin", wangluinLearner),
                ("mp", wmpLearner),
                ("mpm", wmpmLearner),
                ("rs", wrsLearner),
                ("rsm", wrsmLearner)
            ]

main =
    do
        runDFAExperiments
        runNFAExperiments
        runWFAonMooreExperiments
        runWFAVanillaExperiments
        runWFAExperiments
        runWFASparseExperiments
