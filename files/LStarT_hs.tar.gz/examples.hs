{-# LANGUAGE FlexibleInstances #-}

import Control.Monad
import Control.Monad.Writer
import Control.Monad.Trans.State
import Data.Functor.Identity
import Data.Ratio
import Data.Map (Map)
import qualified Data.Map as Map
import Data.Set (Set)
import qualified Data.Set as Set
import System.Random

import LStarT.Automaton
import LStarT.LStarT
import LStarT.CFree
import LStarT.Linear
import LStarT.NonDeterminism
import LStarT.Output
import LStarT.Exceptions
import LStarT.Utils

testDFA ::
    Aut Char Bool Int
testDFA =
    let
        i =
            0
        d q _ =
            case q of
                0 -> 1
                1 -> 2
                2 -> 2
        o q =
            case q of
                0 -> True
                1 -> False
                2 -> True
    in
    Aut {initial = i, delta = d, out = o}

test ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut Identity Char Bool [Char])
test =
    let
        alph =
            ['a']
    in
    lStar (cacheTeacher . countTeacher $ autTeacher alph testDFA)
        (
            Learner {
                decomposeRow = findRow,
                consistencyDefect = plainConsistencyDefect alph,
                ceh = MALER_PNUELI
            }
        )

testDual ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut Identity Char Bool [Char])
testDual =
    let
        alph =
            ['a']
    in
    lStar (cacheTeacher . countTeacher $ autTeacher alph testDFA)
        (
            Learner {
                decomposeRow = findRow,
                consistencyDefect = coClosedness,
                ceh = MALER_PNUELI
            }
        )

testPs ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut FSet Char Bool [Char])
testPs =
    let
        alph =
            ['a']
        alg =
            nonDetAlg
        rowAlg =
            pointwise alg
    in
    lStarT standardDist alg (cacheTeacher . countTeacher $ autTeacher alph testDFA)
        (
            Learner {
                decomposeRow = scrfsaDecompose rowAlg,
                consistencyDefect = lazyConsistencyDefect rowAlg alph,
                ceh = MALER_PNUELI
            }
        )

instance Monoid Bool where
    mempty =
        True
    mappend =
        (&&)

instance Semiring Bool where
    szero =
        False
    sadd =
        (||)

type FLSet = FLinear Bool

testPsL ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut FLSet Char Bool [Char])
testPsL =
    let
        alph =
            ['a']
        alg fl =
            let
                m =
                    fromLinear $ unCFree fl
            in
            Map.member True m && m Map.! True
        rowAlg =
            pointwise alg
    in
    lStarT standardDist alg (cacheTeacher . countTeacher $ autTeacher alph testDFA)
        (
            Learner {
                decomposeRow = lazyDecomposeRow rowAlg,
                consistencyDefect = lazyConsistencyDefect rowAlg alph,
                ceh = MALER_PNUELI
            }
        )

partialAut ::
    Aut Char Bool (Either () Int)
partialAut =
    let
        i =
            Right 0
        d =
            Map.singleton 0 $
                Map.fromList [
                    ('a', Right 0),
                    ('b', Left ())
                ]
        o =
            Map.singleton 0 True
    in
    det standardDist (eitherAlg $ const False) $ SAut {sinitial = i, sdelta = d, sout = o}

testPartial ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut Identity Char Bool [Char])
testPartial =
    let
        alph =
            ['a', 'b']
    in
    lStar (cacheTeacher . countTeacher $ autTeacher alph partialAut)
        (
            Learner {
                decomposeRow = findRow,
                consistencyDefect = plainConsistencyDefect alph,
                ceh = MALER_PNUELI
            }
        )

testPartialEither ::
    StateT (Map [Char] Bool) (State (Int, Int)) (SAut (Either ()) Char Bool [Char])
testPartialEither =
    let
        alph =
            ['a', 'b']
        alg =
            eitherAlg (const False :: () -> Bool)
        rowAlg =
            pointwise alg
    in
    lStarT standardDist alg (cacheTeacher . countTeacher $ autTeacher alph partialAut)
        (
            Learner {
                decomposeRow = lazyDecomposeRow rowAlg,
                consistencyDefect = lazyConsistencyDefect rowAlg alph,
                ceh = MALER_PNUELI
            }
        )

newtype Mod =
    Mod {
        fromMod :: Int
    }

modNumber ::
    Int
modNumber =
    4

instance Eq Mod where
    a == b =
        fromMod a == fromMod b

instance Show Mod where
    show a =
        show $ fromMod a

instance Enumerable Mod where
    enumerate =
        [Mod i | i <- [0 .. modNumber - 1]]

instance Monoid Mod where
    mempty =
        Mod 0
    mappend a b =
        Mod ((fromMod a + fromMod b) `mod` modNumber)

rotationAut ::
    Aut Char Mod Int
rotationAut =
    let
        i =
            0
        d q _ =
            (q + 1) `mod` modNumber
        o =
            Mod
    in
    Aut {initial = i, delta = d, out = o}

testRotation ::
    StateT (Map [Char] Mod) (State (Int, Int)) (SAut Identity Char Mod [Char])
testRotation =
    let
        alph =
            ['a']
    in
    lStar (cacheTeacher . countTeacher $ autTeacher alph rotationAut)
        (
            Learner {
                decomposeRow = findRow,
                consistencyDefect = plainConsistencyDefect alph,
                ceh = MALER_PNUELI
            }
        )

testRotationWriter ::
    StateT (Map [Char] Mod) (State (Int, Int)) (SAut (Writer Mod) Char Mod [Char])
testRotationWriter =
    let
        alph =
            ['a']
        alg =
            uncurry mappend . runWriter
        rowAlg =
            pointwise alg
    in
    lStarT standardDist alg (cacheTeacher . countTeacher $ autTeacher alph rotationAut)
        (
            Learner {
                decomposeRow = lazyDecomposeRow rowAlg,
                consistencyDefect = lazyConsistencyDefect rowAlg alph,
                ceh = MALER_PNUELI
            }
        )

instance Monoid Rational where
    mempty = 1 % 1
    mappend = (*)

instance Semiring Rational where
    szero = 0 % 1
    sadd = (+)

instance Ring Rational where
    rnegation = (szero -)

instance Field Rational where
    finverse = (mone /)

weightedAut ::
    Aut Char Rational (FLinear Rational Int)
weightedAut =
    let
        toFL =
            inject . Linear . Map.fromList
        i =
            toFL [(0, 1 % 1)]
        d =
            Map.fromList [
                (0,
                    Map.fromList [
                        ('a', toFL [(1, 1 % 1)])
                    ]
                ),
                (1,
                    Map.fromList [
                        ('a', toFL [(2, 3 % 1)])
                    ]
                ),
                (2,
                    Map.fromList [
                        ('a', toFL [(2, 5 % 1), (0, 1 % 1)])
                    ]
                )
            ]
        o =
            Map.fromList [(0, 1), (1, 1), (2, 1)]
    in
    det standardDist (linearEval . unCFree) $ SAut {sinitial = i, sdelta = d, sout = o}

testWeighted ::
    StateT (Map [Char] Rational) (State (Int, Int)) (SAut (FLinear Rational) Char Rational [Char])
testWeighted =
    let
        alph =
            ['a']
        alg =
            linearEval . unCFree
    in
    lStarT standardDist alg (cacheTeacher . countTeacher $ autTeacherT inSpan alph weightedAut)
        (
            Learner {
                decomposeRow = gaussianDecomposeRow,
                consistencyDefect = coClosedness,
                ceh = MALER_PNUELI
            }
        )

randomDFA ::
    [Char] -> Int -> State StdGen (SAut Identity Char Bool Int)
randomDFA alph n =
    let
        states =
            [1 .. n]
    in
    randomSAut alph (uniform enumerate) states (Identity <$> uniform states)

testRandom ::
    State StdGen (StateT (Map [Char] Bool) (State (Int, Int)) (SAut Identity Char Bool [Char]))
testRandom =
    let
        alph =
            ['a']
        states =
            10
    in
    do
        dfa <- det runIdentity runIdentity <$> randomDFA alph states
        return $ lStar (cacheTeacher . countTeacher $ autTeacher alph dfa)
            (
                Learner {
                    decomposeRow = findRow,
                    consistencyDefect = plainConsistencyDefect alph,
                    ceh = MALER_PNUELI
                }
            )

main =
    do
        print $ runState (runStateT test Map.empty) (0, 0)
        print $ runState (runStateT testDual Map.empty) (0, 0)
        print $ runState (runStateT testPs Map.empty) (0, 0)
        print $ runState (runStateT testPsL Map.empty) (0, 0)
        print $ runState (runStateT testPartial Map.empty) (0, 0)
        print $ runState (runStateT testPartialEither Map.empty) (0, 0)
        print $ runState (runStateT testRotation Map.empty) (0, 0)
        print $ runState (runStateT testRotationWriter Map.empty) (0, 0)
        print $ runState (runStateT testWeighted Map.empty) (0, 0)
        let r = evalState testRandom $ mkStdGen 37
        print $ runState (runStateT r Map.empty) (0, 0)
