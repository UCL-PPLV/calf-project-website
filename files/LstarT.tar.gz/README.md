# L\*T

L\*T optimizes the L\* algorithm due to Dana Angluin by learning automata
enriched with side-effects given by a monad.

To instantiate the algorithm, one must first define an oracle that answers
membership and equivalence queries. One of the predefined oracles takes the
target language in the form as an automaton as a parameter.
For example, the following defines a DFA with a single alphabet character and
three states.
```java
Moore<Integer, Character, Boolean> dfa = new Moore<Integer, Character, Boolean>(0);
dfa.setOutput(0, true);
dfa.setOutput(1, false);
dfa.setOutput(2, true);
dfa.addTransition(0, 'a', 1);
dfa.addTransition(1, 'a', 2);
dfa.addTransition(2, 'a', 2);
MooreOracle<Integer, Character, Boolean> oracle = new MooreOracle<Integer, Character, Boolean>(dfa);
```
There are several oracle extensions. For instance, the following creates an
oracle that keeps track of the number of queries asked to a specified oracle.
```java
CounterOracle<Character, Boolean> counter = new CounterOracle<Character, Boolean>(oracle);
```
One may also create a membership query cache on top of this, as follows.
```java
CacheOracle<Character, Boolean> cache = new CacheOracle<Character, Boolean>(counter);
```
Once the oracle is defined, it is time to choose the learning algorithm. These
algorithms are provided by subclasses of the abstract `ObservationTable` class.
For example, the following initializes a table for the (Moore automaton
generalization of the) standard L\* algorithm.
```java
ObservationTable<Character, Boolean> table = new MooreObservationTable<Character, Boolean>(cache);
```
One may take advantage of the JSL structure on the `Boolean` type and instead
define the following table.
```java
ObservationTable<Character, Boolean> table = new NFAObservationTable<Character>(cache, true);
```
The second parameter indicates that the hypotheses construction strategy is the
one analogous to the _simplified_ canonical RFSA rather than the canonical
RFSA. Once the table has been setup, the `lstar` method will run the algorithm
and return the final hypothesis.
```java
table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
```
Here the first argument defines the counterexample handling method, which is
one of `ANGLUIN`, `MALER_PNUELI`, or `RIVEST_SCHAPIRE`, and the second
parameter defines whether we want to run consistency checks.

The example described here can be found in the `testUnion` method of the
`Examples` class.

## Building

To build the code, run a java compiler on the java files found in the
`source` folder.

## Running

L\*T should be seen as a library. However, one may run the example class
`Examples` or our experiments class `Experiments`.
