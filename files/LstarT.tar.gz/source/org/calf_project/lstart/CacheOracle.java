package org.calf_project.lstart;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class CacheOracle<A, O> extends OracleExtender<A, O> {
	private Map<List<A>, O> cache;

	public CacheOracle(Oracle<A, O> oracle) {
		super(oracle);
		cache = new HashMap<List<A>, O>();
	}

	@Override
	public O membership(List<A> word) {
		O result;
		if ((result = cache.get(word)) != null)
			return result;
		result = super.membership(word);
		cache.put(word, result);
		return result;
	}
}
