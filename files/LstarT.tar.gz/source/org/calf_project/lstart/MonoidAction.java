package org.calf_project.lstart;

public interface MonoidAction<M, X> {
	public X mult(M m, X x);
}
