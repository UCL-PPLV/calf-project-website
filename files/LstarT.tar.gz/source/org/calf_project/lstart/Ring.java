package org.calf_project.lstart;

public abstract class Ring<R> extends Semiring<R> {
	public abstract R negate(R r);

	public R minus(R a, R b) {
		return add(a, negate(b));
	}
}
