package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class Results extends ArrayList<Double> {
	public double sum() {
		double result = 0;
		for (Double v : this)
			result += v;
		return result;
	}

	public double average() {
		return sum() / size();
	}

	public double variance() {
		double result = 0;
		double avg = average();
		int n = size();
		for (Double v : this)
			result += Math.pow(v - avg, 2) / n;
		return result;
	}

	public double stddev() {
		return Math.sqrt(variance());
	}

	public Result summarise() {
		return new Result(average(), stddev());
	}
}
