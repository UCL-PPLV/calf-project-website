package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;

public class Moore<Q, A, O> {
	private Q initial;
	private Map<Q, Map<A, Q>> transitions;
	private Map<Q, O> outputs;

	public Moore(Q initial) {
		this.initial = initial;
		transitions = new HashMap<Q, Map<A, Q>>();
		outputs = new HashMap<Q, O>();
	}

	public void addTransition(Q origin, A a, Q target) {
		Map<A, Q> map = transitions.get(origin);
		if (map == null) {
			map = new HashMap<A, Q>();
			transitions.put(origin, map);
		}
		map.put(a, target);
	}

	public void setOutput(Q state, O output) {
		outputs.put(state, output);
	}

	protected Q advance(Q q, A a) {
		return transitions.get(q).get(a);
	}

	protected O output(Q q) {
		return outputs.get(q);
	}

	public Q getState(List<A> word) {
		Q q = initial;
		for (A a : word)
			q = advance(q, a);
		return q;
	}

	public O run(List<A> word) {
		return output(getState(word));
	}

	public <R> List<A> distinguish(Moore<R, A, O> other, List<A> alphabet) {
		SimulationBuilder<Q, R, List<A>> b = new SimulationBuilder<Q, R, List<A>>();
		b.add(initial, other.initial, new ArrayList<A>());
		while (!b.done()) {
			Q q = b.getA();
			R r = b.getB();
			for (A a : alphabet) {
				Q qq = advance(q, a);
				R rr = other.advance(r, a);
				List<A> word = new ArrayList<A>(b.getEtc());
				word.add(a);
				if (!output(qq).equals(other.output(rr)))
					return word;
				b.add(qq, rr, word);
			}
			b.advance();
		}
		return null;
	}

	public int size() {
		return outputs.size();
	}

	public List<A> getAlphabet() {
		for (Map<A, Q> values : transitions.values())
			return new ArrayList<A>(values.keySet());
		return null;
	}

	public String toString() {
		return initial.toString() + " : " + outputs.toString() + " : " + transitions.toString();
	}

	public static <Q, A, O> Moore<Q, A, O> random(long seed, List<Q> states, List<A> symbols, List<O> outputs) {
		Random random = new Random(seed);
		Moore<Q, A, O> result = new Moore<Q, A, O>(states.get(0));
		for (Q q : states) {
			result.setOutput(q, outputs.get(random.nextInt(outputs.size())));
			for (A a : symbols)
				result.addTransition(q, a, states.get(random.nextInt(states.size())));
		}
		return result;
	}
}
