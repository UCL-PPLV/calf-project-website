package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class NFAObservationTable<A> extends WFAObservationTable<Boolean, A, Boolean> {
	protected static NonDeterminism nd = new NonDeterminism();
	protected boolean simplify;

	public NFAObservationTable(Oracle<A, Boolean> oracle, boolean simplify) {
		super(oracle, nd, nd, nd.values());
		this.simplify = simplify;
	}

	protected static boolean lt(List<Boolean> x, List<Boolean> y) {
		if (x.size() != y.size())
			return false;
		for (int i = 0; i < x.size(); i++) {
			if (x.get(i) && !y.get(i))
				return false;
		}
		return true;
	}

	public boolean hasRow(List<Boolean> row) {
		List<Boolean> acc = new ArrayList<Boolean>();
		for (Boolean b : row)
			acc.add(false);
		for (List<Boolean> other : ttable.values()) {
			if (lt(other, row)) {
				for (int i = 0; i < other.size(); i++) {
					if (other.get(i))
						acc.set(i, true);
				}
			}
		}
		return acc.equals(row);
	}

	@Override
	protected Map<List<A>, Boolean> decompose(List<Boolean> row, List<List<A>> rows) {
		Map<List<A>, Boolean> result = new HashMap<List<A>, Boolean>();
		List<Boolean> acc = new ArrayList<Boolean>();
		for (Boolean b : row)
			acc.add(false);
		for (List<A> label : rows) {
			result.put(label, true);
			List<Boolean> other = ttable.get(label);
			if (lt(other, row)) {
				if (simplify) {
					for (List<A> label2 : rows) {
						List<Boolean> yetanother = ttable.get(label2);
						if (!yetanother.equals(other) && lt(other, yetanother) && lt(yetanother, row)) {
							result.put(label, false);
							break;
						}
					}
				}
				for (int i = 0; i < other.size(); i++) {
					if (other.get(i))
						acc.set(i, true);
				}
			} else {
				result.put(label, false);
			}
		}
		if (acc.equals(row))
			return result;
		return null;
	}
}
