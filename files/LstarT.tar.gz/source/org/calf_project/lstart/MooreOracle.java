package org.calf_project.lstart;

import java.util.List;

public class MooreOracle<Q, A, O> extends MooreLanguage<Q, A, O> implements Oracle<A, O> {
	private List<A> alphabet;

	public MooreOracle(Moore<Q, A, O> moore) {
		super(moore);
		alphabet = moore.getAlphabet();
	}

	public List<A> alphabet() {
		return alphabet;
	}

	public List<A> equivalence(Moore<?, A, O> hyp) {
		return hyp.distinguish(moore, alphabet);
	}
}
