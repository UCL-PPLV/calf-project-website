package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class Universal extends Semimodule<Boolean, Boolean> {
	public Boolean zero() {
		return true;
	}

	public Boolean add(Boolean a, Boolean b) {
		return a && b;
	}

	public Boolean mult(Boolean a, Boolean b) {
		return a && b;
	}
}
