package org.calf_project.lstart;

public abstract class Semiring<S> extends Semimodule<S, S> {
	public abstract S one();
}
