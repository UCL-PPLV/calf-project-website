package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;

class MooreObservationTable<A, O> extends ObservationTable<A, O> {
	protected Moore<List<A>, A, O> hyp;

	public MooreObservationTable(Oracle<A, O> oracle) {
		super(oracle);
	}

	public boolean hasRow(List<O> row) {
		return ttable.containsValue(row);
	}

	public boolean consistent() {
		for (Map.Entry<List<A>, List<O>> entry1 : ttable.entrySet()) {
			for (Map.Entry<List<A>, List<O>> entry2 : ttable.entrySet()) {
				if (entry1.getValue().equals(entry2.getValue())) {
					for (A a : alphabet) {
						List<A> label1 = new ArrayList<A>(entry1.getKey());
						label1.add(a);

						List<A> label2 = new ArrayList<A>(entry2.getKey());
						label2.add(a);

						if (fixDiscrepancy(btable.get(label1), btable.get(label2), a))
							return false;
					}
				}
			}
		}
		return true;
	}

	protected List<List<A>> minimise() {
		List<List<A>> result = new ArrayList<List<A>>(ttable.keySet());
		java.util.Collections.reverse(result);
		Iterator<List<A>> it = result.iterator();
		while (it.hasNext()) {
			List<A> s = it.next();
			List<O> row = ttable.get(s);
			for (List<A> other : result) {
				if (!other.equals(s) && ttable.get(other).equals(row)) {
					it.remove();
					break;
				}
			}
		}
		return result;
	}

	protected List<A> decompose(List<O> row, List<List<A>> rows) {
		for (List<A> s : rows) {
			if (ttable.get(s).equals(row))
				return s;
		}
		return null;
	}

	protected O distortedMembership(List<A> own, List<A> other) {
		List<A> word = new ArrayList<A>(hyp.getState(own));
		word.addAll(other);
		return oracle.membership(word);
	}

	public Moore<List<A>, A, O> hypothesis() {
		List<List<A>> minimal = minimise();
		hyp = new Moore<List<A>, A, O>(decompose(ttable.get(new ArrayList<A>()), minimal));

		for (List<A> label : minimal) {
			hyp.setOutput(label, ttable.get(label).get(0));
			for (A a : alphabet) {
				List<A> labela = new ArrayList<A>(label);
				labela.add(a);
				hyp.addTransition(label, a, decompose(btable.get(labela), minimal));
			}
		}

		return hyp;
	}
}
