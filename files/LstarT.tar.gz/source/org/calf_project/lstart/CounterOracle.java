package org.calf_project.lstart;

import java.util.List;

public class CounterOracle<A, O> extends OracleExtender<A, O> {
	int mqCount;
	int eqCount;

	public CounterOracle(Oracle<A, O> oracle) {
		super(oracle);
		mqCount = 0;
		eqCount = 0;
	}

	@Override
	public List<A> equivalence(Moore<?, A, O> hyp) {
		eqCount++;
		return oracle.equivalence(hyp);
	}

	@Override
	public O membership(List<A> word) {
		mqCount++;
		return oracle.membership(word);
	}

	public int getMQCount() {
		return mqCount;
	}

	public int getEQCount() {
		return eqCount;
	}

	public void printStatus() {
		System.out.println("mqs: " + getMQCount() + ", eqs: " + getEQCount());
	}
}
