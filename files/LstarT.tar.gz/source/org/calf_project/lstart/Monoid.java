package org.calf_project.lstart;

public interface Monoid<X> {
	public X zero();
	public X add(X a, X b);
}
