package org.calf_project.lstart;

import java.util.Map;

abstract class Semimodule<S, X> implements Monoid<X>, MonoidAction<S, X> {
	public X combine(Map<X, S> m) {
		X result = zero();
		for (Map.Entry<X, S> entry : m.entrySet())
			result = add(result, mult(entry.getValue(), entry.getKey()));
		return result;
	}
}
