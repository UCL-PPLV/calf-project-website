package org.calf_project.lstart;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class NFA<Q, A> extends WFA<Boolean, Q, A, Boolean> {
	private static final NonDeterminism nd = new NonDeterminism();

	public NFA(Map<Q, Boolean> initial) {
		super(initial, nd, nd);
	}

	public static <Q, A> NFA<Q, A> random(long seed, List<Q> states, List<A> symbols, int transitions, int accepting) {
		Random random = new Random(seed);
		Map<Q, Boolean> initial = new HashMap<Q, Boolean>();
		initial.put(states.get(0), true);
		NFA<Q, A> result = new NFA<Q, A>(initial);
		int n = states.size();
		RandomOrder order = new RandomOrder(n);
		for (int i = 0; i < n; i++) {
			Q q = states.get(order.next(random));
			if (i < accepting)
				result.setOutput2(q, true);
			else
				result.setOutput2(q, false);
		}
		for (A a : symbols) {
			Map<Q, Map<Q, Boolean>> buffer = new HashMap<Q, Map<Q, Boolean>>();
			for (Q origin : states) {
				Map<Q, Boolean> t = new HashMap<Q, Boolean>();
				for (Q target : states)
					t.put(target, false);
				buffer.put(origin, t);
			}
			int pairs = n * n;
			order = new RandomOrder(pairs);
			for (int i = 0; i < transitions; i++) {
				int pair = order.next(random);
				Q origin = states.get(pair / n);
				Q target = states.get(pair % n);
				buffer.get(origin).put(target, true);
			}
			for (Q q : states)
				result.addTransition(q, a, buffer.get(q));
		}
		return result;
	}
}
