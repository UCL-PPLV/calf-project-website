package org.calf_project.lstart;

import java.util.Map;
import java.util.HashMap;

public class MFA<M, Q, A, O> extends Moore<Tuple<M, Q>, A, O> {
	protected Monoid<M> m;
	protected MonoidAction<M, O> ma;

	public MFA(Tuple<M, Q> initial, Monoid<M> m, MonoidAction<M, O> ma) {
		super(initial);
		this.m = m;
		this.ma = ma;
	}

	protected Tuple<M, Q> unit(Q q) {
		return new Tuple<M, Q>(m.zero(), q);
	}

	public void addTransition(Q origin, A a, Tuple<M, Q> t) {
		addTransition(unit(origin), a, t);
	}

	public void setOutput2(Q q, O o) {
		setOutput(unit(q), o);
	}

	@Override
	protected Tuple<M, Q> advance(Tuple<M, Q> qs, A a) {
		M v = qs.getFst();
		Q q = qs.getSnd();
		Tuple<M, Q> result = super.advance(unit(q), a);
		return new Tuple<M, Q>(m.add(v, result.getFst()), result.getSnd());
	}

	@Override
	protected O output(Tuple<M, Q> t) {
		return ma.mult(t.getFst(), super.output(unit(t.getSnd())));
	}
}
