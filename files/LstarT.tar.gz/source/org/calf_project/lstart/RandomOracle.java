package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class RandomOracle<A, O> implements Oracle<A, O> {
	private Language<A, O> lang;
	private List<A> alphabet;
	private int queries;
	private double stopOdds;

	public RandomOracle(Language<A, O> lang, List<A> alphabet, int queries, double stopOdds) {
		this.lang = lang;
		this.alphabet = alphabet;
		this.queries = queries;
		this.stopOdds = stopOdds;
	}

	public List<A> alphabet() {
		return alphabet;
	}

	public O membership(List<A> word) {
		return lang.membership(word);
	}

	public List<A> equivalence(Moore<?, A, O> hyp) {
		for (int i = 0; i < queries; i++) {
			List<A> word = new ArrayList<A>();
			Random random = new Random();
			while (random.nextDouble() >= stopOdds)
				word.add(alphabet.get(random.nextInt(alphabet.size())));
			if (!membership(word).equals(hyp.run(word)))
				return word;
		}
		return null;
	}
}
