package org.calf_project.lstart;

import java.util.List;

public interface Language<A, O> {
	public O membership(List<A> word);
}
