package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class RandomOrder {
	private List<Integer> list;
	private int remaining;

	public RandomOrder(int size) {
		list = new ArrayList<Integer>(size);
		for (int i = 0; i < size; i++)
			list.add(i);
		remaining = size;
	}

	public boolean done() {
		return remaining == 0;
	}

	public int next(Random random) {
		int index = random.nextInt(remaining--);
		int result = list.get(index);
		list.set(index, list.get(remaining));
		return result;
	}
}
