package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

class WFAObservationTable<S, A, O> extends ObservationTable<A, O> {
	protected Semiring<S> sr;
	protected Semimodule<S, O> sm;
	protected List<S> values;
	protected WFA<S, List<A>, A, O> hyp;

	public WFAObservationTable(Oracle<A, O> oracle, Semiring<S> sr, Semimodule<S, O> sm, List<S> values) {
		super(oracle);
		this.sr = sr;
		this.sm = sm;
		this.values = values;
	}

	protected List<O> tableSemimodule(Map<List<O>, S> rows) {
		List<Map<O, S>> acc = new ArrayList<Map<O, S>>();
		for (Map.Entry<List<O>, S> entry : rows.entrySet()) {
			int i = 0;
			for (O o : entry.getKey()) {
				Map<O, S> current;
				if (acc.size() <= i) {
					current = new HashMap<O, S>();
					acc.add(current);
				} else {
					current = acc.get(i);
				}
				S value = current.get(o);
				if (value == null)
					current.put(o, entry.getValue());
				else
					current.put(o, sr.add(value, entry.getValue()));
				i++;
			}
		}
		List<O> result = new ArrayList<O>();
		for (Map<O, S> sub : acc)
			result.add(sm.combine(sub));
		return result;
	}

	protected <X> List<Map<X, S>> combinations(List<X> list) {
		List<Map<X, S>> result = new ArrayList<Map<X, S>>();
		if (list.isEmpty()) {
			result.add(new HashMap<X, S>());
		} else {
			X x = list.get(0);
			List<X> tail = list.subList(1, list.size());
			for (S s : values) {
				List<Map<X, S>> previous = combinations(tail);
				for (Map<X, S> m : previous) {
					m.put(x, s);
					result.add(m);
				}
			}
		}
		return result;
	}

	public boolean hasRow(List<O> row) {
		for (Map<List<O>, S> com : combinations(new ArrayList<List<O>>(ttable.values()))) {
			if (row.equals(tableSemimodule(com)))
				return true;
		}
		return false;
	}

	protected List<O> rowCombination(Map<List<A>, S> labels, Map<List<A>, List<O>> table) {
		Map<List<O>, S> result = new HashMap<List<O>, S>();
		for (Map.Entry<List<A>, S> entry : labels.entrySet()) {
			List<O> row = table.get(entry.getKey());
			S value = entry.getValue();
			S current = result.get(row);
			if (current == null)
				result.put(row, value);
			else
				result.put(row, sr.add(current, value));
		}
		return tableSemimodule(result);
	}

	protected Map<List<A>, S> advance(Map<List<A>, S> labels, A a) {
		Map<List<A>, S> result = new HashMap<List<A>, S>();
		for (List<A> label : labels.keySet()) {
			List<A> labela = new ArrayList<A>(label);
			labela.add(a);
			result.put(labela, labels.get(label));
		}
		return result;
	}

	public boolean consistent() {
		List<List<A>> rowList = new ArrayList<List<A>>(ttable.keySet());
		List<Map<List<A>, S>> coms = combinations(rowList);
		for (Map<List<A>, S> com1 : coms) {
			for (Map<List<A>, S> com2 : coms) {
				if (rowCombination(com1, ttable).equals(rowCombination(com2, ttable))) {
					for (A a : alphabet) {
						List<O> row1 = rowCombination(advance(com1, a), btable);
						List<O> row2 = rowCombination(advance(com2, a), btable);
						if (fixDiscrepancy(row1, row2, a))
							return false;
					}
				}
			}
		}
		return true;
	}

	protected Map<List<A>, S> decompose(List<O> row, List<List<A>> rows) {
		for (Map<List<A>, S> com : combinations(rows)) {
			if (rowCombination(com, ttable).equals(row))
				return com;
		}
		return null;
	}

	protected List<List<A>> minimise() {
		List<List<A>> result = new ArrayList<List<A>>(ttable.keySet());
		java.util.Collections.reverse(result);
		Iterator<List<A>> it = result.iterator();
		while (it.hasNext()) {
			List<A> s = it.next();
			List<O> row = ttable.get(s);
			List<List<A>> others = new ArrayList<List<A>>(result);
			others.remove(s);
			if (decompose(row, others) != null)
				it.remove();
		}
		return result;
	}

	protected O distortedMembership(List<A> own, List<A> other) {
		Map<O, S> result = new HashMap<O, S>();
		Map<List<A>, S> qs = hyp.getState(own);
		for (Map.Entry<List<A>, S> entry : qs.entrySet()) {
			List<A> word = new ArrayList<A>(entry.getKey());
			word.addAll(other);
			O o = oracle.membership(word);
			S value = entry.getValue();
			S current = result.get(o);
			if (current == null)
				result.put(o, value);
			else
				result.put(o, sr.add(value, current));
		}
		return sm.combine(result);
	}

	public WFA<S, List<A>, A, O> hypothesis() {
		List<List<A>> minimal = minimise();
		hyp = new WFA<S, List<A>, A, O>(decompose(ttable.get(new ArrayList<A>()), minimal), sr, sm);

		for (List<A> label : minimal) {
			hyp.setOutput2(label, ttable.get(label).get(0));
			for (A a : alphabet) {
				List<A> labela = new ArrayList<A>(label);
				labela.add(a);
				hyp.addTransition(label, a, decompose(btable.get(labela), minimal));
			}
		}

		return hyp;
	}
}
