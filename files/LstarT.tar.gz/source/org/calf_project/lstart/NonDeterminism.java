package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class NonDeterminism extends Semiring<Boolean> {
	private List<Boolean> values;

	public NonDeterminism() {
		values = new ArrayList<Boolean>();
		values.add(false);
		values.add(true);
	}

	public List<Boolean> values() {
		return values;
	}

	public Boolean zero() {
		return false;
	}

	public Boolean one() {
		return true;
	}

	public Boolean add(Boolean a, Boolean b) {
		return a || b;
	}

	public Boolean mult(Boolean a, Boolean b) {
		return a && b;
	}
}
