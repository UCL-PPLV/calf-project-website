package org.calf_project.lstart;

import java.util.List;

public class MooreLanguage<Q, A, O> implements Language<A, O> {
	protected Moore<Q, A, O> moore;

	public MooreLanguage(Moore<Q, A, O> moore) {
		this.moore = moore;
	}

	public O membership(List<A> word) {
		return moore.run(word);
	}
}
