package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class Experiments {
	public static void runDFAExperiments() {
		int start = 20;
		int end = 200;
		int step = 20;
		int alphabetSize = 3;
		int iterations = 100;

		Experiment lstar = new Experiment();
		Experiment lstarMP = new Experiment();
		Experiment lstarRS = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		List<Boolean> outputs = new ArrayList<Boolean>();
		outputs.add(false);
		outputs.add(true);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Boolean> counter;
				CacheOracle<Integer, Boolean> cache;
				ObservationTable<Integer, Boolean> table;
				Moore<?, Integer, Boolean> hyp;

				Moore<Integer, Integer, Boolean> ref;
				Oracle<Integer, Boolean> oracle;

				ref = Moore.random(seed++, states, alphabet, outputs);
				oracle = new MooreOracle<Integer, Integer, Boolean>(ref);

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				lstar.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				lstarMP.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				lstarRS.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			lstar.save(label);
			lstarMP.save(label);
			lstarRS.save(label);
		}

		lstar.write("experiments/dfa/lstar");
		lstarMP.write("experiments/dfa/lstarMP");
		lstarRS.write("experiments/dfa/lstarRS");
	}

	public static void runMooreExperiments() {
		int start = 20;
		int end = 200;
		int step = 20;
		int alphabetSize = 3;
		int outputSize = 5;
		int iterations = 100;

		Experiment lstar = new Experiment();
		Experiment lstarMP = new Experiment();
		Experiment lstarRS = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		List<Integer> outputs = new ArrayList<Integer>();
		for (int i = 0; i < outputSize; i++)
			outputs.add(i);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Integer> counter;
				CacheOracle<Integer, Integer> cache;
				ObservationTable<Integer, Integer> table;
				Moore<?, Integer, Integer> hyp;

				Moore<Integer, Integer, Integer> ref;
				Oracle<Integer, Integer> oracle;

				ref = Moore.random(seed++, states, alphabet, outputs);
				oracle = new MooreOracle<Integer, Integer, Integer>(ref);

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new MooreObservationTable<Integer, Integer>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				lstar.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new MooreObservationTable<Integer, Integer>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				lstarMP.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new MooreObservationTable<Integer, Integer>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				lstarRS.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			lstar.save(label);
			lstarMP.save(label);
			lstarRS.save(label);
		}

		lstar.write("experiments/moore/lstar");
		lstarMP.write("experiments/moore/lstarMP");
		lstarRS.write("experiments/moore/lstarRS");
	}

	public static void runWFAVanillaExperiments() {
		int fieldSize = 5;
		int alphabetSize = 3;
		int start = 1;
		int end = 5;
		int step = 1;
		int iterations = 100;

		Zn zn = new Zn(fieldSize);

		Experiment angluin = new Experiment();
		Experiment mp = new Experiment();
		Experiment rs = new Experiment();
		Experiment weighted = new Experiment();
		Experiment weightedmp = new Experiment();
		Experiment weightedrs = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Integer> counter;
				CacheOracle<Integer, Integer> cache;
				ObservationTable<Integer, Integer> table;
				Moore<?, Integer, Integer> hyp;

				Moore<Map<Integer, Integer>, Integer, Integer> ref;
				Oracle<Integer, Integer> oracle;

				ref = WFA.random(seed++, states, alphabet, zn.values(), zn, zn, zn.values());
				oracle = new MooreOracle<Map<Integer, Integer>, Integer, Integer>(ref);

				//counter = new CounterOracle<Integer, Integer>(oracle);
				//cache = new CacheOracle<Integer, Integer>(counter);
				//table = new MooreObservationTable<Integer, Integer>(cache);
				//hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				//angluin.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				//counter = new CounterOracle<Integer, Integer>(oracle);
				//cache = new CacheOracle<Integer, Integer>(counter);
				//table = new MooreObservationTable<Integer, Integer>(cache);
				//hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				//mp.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				//counter = new CounterOracle<Integer, Integer>(oracle);
				//cache = new CacheOracle<Integer, Integer>(counter);
				//table = new MooreObservationTable<Integer, Integer>(cache);
				//hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				//rs.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				//counter = new CounterOracle<Integer, Integer>(oracle);
				//cache = new CacheOracle<Integer, Integer>(counter);
				//table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				//hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				//weighted.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
				weightedmp.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
				weightedrs.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			//angluin.save(label);
			//mp.save(label);
			//rs.save(label);
			//weighted.save(label);
			weightedmp.save(label);
			weightedrs.save(label);
		}

		//angluin.write("experiments/wfa/vangluin");
		//mp.write("experiments/wfa/vmp");
		//rs.write("experiments/wfa/vrs");
		//weighted.write("experiments/wfa/weighted");
		weightedmp.write("experiments/wfa/weightedmp");
		weightedrs.write("experiments/wfa/weightedrs");
	}

	public static void runWFAonMooreExperiments() {
		int fieldSize = 5;
		int alphabetSize = 3;
		int start = 5;
		int end = 50;
		int step = 5;
		int iterations = 100;

		Zn zn = new Zn(fieldSize);

		Experiment vangluin = new Experiment();
		Experiment angluin = new Experiment();
		Experiment mp = new Experiment();
		Experiment mpm = new Experiment();
		Experiment rs = new Experiment();
		Experiment rsm = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Integer> counter;
				CacheOracle<Integer, Integer> cache;
				ObservationTable<Integer, Integer> table;
				Moore<?, Integer, Integer> hyp;

				Moore<Integer, Integer, Integer> ref;
				Oracle<Integer, Integer> oracle;

				ref = Moore.random(seed++, states, alphabet, zn.values());
				oracle = new MooreOracle<Integer, Integer, Integer>(ref);

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new MooreObservationTable<Integer, Integer>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				vangluin.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				angluin.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
				mp.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				mpm.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
				rs.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				rsm.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			vangluin.save(label);
			angluin.save(label);
			mp.save(label);
			mpm.save(label);
			rs.save(label);
			rsm.save(label);
		}

		vangluin.write("experiments/wfa/vangluinDFA");
		angluin.write("experiments/wfa/angluinDFA");
		mp.write("experiments/wfa/mpDFA");
		mpm.write("experiments/wfa/mpmDFA");
		rs.write("experiments/wfa/rsDFA");
		rsm.write("experiments/wfa/rsmDFA");
	}

	public static void runWFAExperiments() {
		int fieldSize = 5;
		int alphabetSize = 3;
		int start = 5;
		int end = 50;
		int step = 5;
		int iterations = 100;
		int tests = 10000;
		double stopProbability = 0.08;

		Zn zn = new Zn(fieldSize);

		Experiment angluin = new Experiment();
		Experiment mp = new Experiment();
		Experiment mpm = new Experiment();
		Experiment rs = new Experiment();
		Experiment rsm = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Integer> counter;
				CacheOracle<Integer, Integer> cache;
				ObservationTable<Integer, Integer> table;
				Moore<?, Integer, Integer> hyp;

				Moore<Map<Integer, Integer>, Integer, Integer> ref;
				Oracle<Integer, Integer> oracle;

				ref = WFA.random(seed++, states, alphabet, zn.values(), zn, zn, zn.values());
				oracle = new RandomOracle<Integer, Integer>(new MooreLanguage<Map<Integer, Integer>, Integer, Integer>(ref), alphabet, tests, stopProbability);

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				angluin.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
				mp.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				mpm.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
				rs.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Integer>(oracle);
				cache = new CacheOracle<Integer, Integer>(counter);
				table = new FWFAObservationTable<Integer, Integer>(cache, zn, zn.values());
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				rsm.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			angluin.save(label);
			mp.save(label);
			mpm.save(label);
			rs.save(label);
			rsm.save(label);
		}

		angluin.write("experiments/wfa/angluin");
		mp.write("experiments/wfa/mp");
		mpm.write("experiments/wfa/mpm");
		rs.write("experiments/wfa/rs");
		rsm.write("experiments/wfa/rsm");
	}

	public static void runNFAExperiments() {
		int start = 4;
		int end = 16;
		int step = 4;
		int alphabetSize = 3;
		double transitionDensity = 1.25;
		double acceptDensity = 0.5;
		int iterations = 100;

		Experiment lstar = new Experiment();
		Experiment lstarMP = new Experiment();
		Experiment lstarRS = new Experiment();
		Experiment nlstarMP = new Experiment();
		Experiment nlstarMPNC = new Experiment();
		Experiment nlstarRS = new Experiment();
		Experiment nlstarRSNC = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		int seed = 0;
		for (int n = start; n <= end; n+= step) {
			List<Integer> states = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				states.add(i);

			for (int i = 0; i < iterations; i++) {
				System.out.println("Size " + n + ", experiment " + (i + 1) + " / " + iterations);
				CounterOracle<Integer, Boolean> counter;
				CacheOracle<Integer, Boolean> cache;
				ObservationTable<Integer, Boolean> table;
				Moore<?, Integer, Boolean> hyp;

				Moore<Map<Integer, Boolean>, Integer, Boolean> ref;
				Oracle<Integer, Boolean> oracle;

				ref = NFA.random(seed++, states, alphabet, (int)Math.round(n * transitionDensity), (int)Math.round(n * acceptDensity));
				oracle = new MooreOracle<Map<Integer, Boolean>, Integer, Boolean>(ref);

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				lstar.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				lstarMP.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				lstarRS.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
				nlstarMP.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				nlstarMPNC.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
				nlstarRS.add(counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				nlstarRSNC.add(counter.getEQCount(), counter.getMQCount(), hyp.size());
			}

			String label = Integer.toString(n);
			lstar.save(label);
			lstarMP.save(label);
			lstarRS.save(label);
			nlstarMP.save(label);
			nlstarMPNC.save(label);
			nlstarRS.save(label);
			nlstarRSNC.save(label);
		}

		lstar.write("experiments/nfa/lstar");
		lstarMP.write("experiments/nfa/lstarMP");
		lstarRS.write("experiments/nfa/lstarRS");
		nlstarMP.write("experiments/nfa/nlstarMP");
		nlstarMPNC.write("experiments/nfa/nlstarMPNC");
		nlstarRS.write("experiments/nfa/nlstarRS");
		nlstarRSNC.write("experiments/nfa/nlstarRSNC");
	}

	public static void runReorderedNFAExperiments() {
		int nfaSize = 8;
		int alphabetSize = 3;
		double transitionDensity = 1.25;
		double acceptDensity = 0.5;
		int bins = 10;
		int binSize = 10;
		int iterations = 3000;

		Experiment lstar = new Experiment();
		Experiment lstarMP = new Experiment();
		Experiment lstarRS = new Experiment();
		Experiment nlstarMP = new Experiment();
		Experiment nlstarMPNC = new Experiment();
		Experiment nlstarRS = new Experiment();
		Experiment nlstarRSNC = new Experiment();

		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < alphabetSize; i++)
			alphabet.add(i);

		List<Integer> states = new ArrayList<Integer>();
		for (int i = 0; i < nfaSize; i++)
			states.add(i);

		for (int i = 0; i < bins; i++) {
			String label = Integer.toString(i * binSize);
			lstar.save(label);
			lstarMP.save(label);
			lstarRS.save(label);
			nlstarMP.save(label);
			nlstarMPNC.save(label);
			nlstarRS.save(label);
			nlstarRSNC.save(label);
		}

		int seed = 0;
		for (int i = 0; i < iterations; i++) {
			System.out.println("Experiment " + (i + 1) + " / " + iterations);
			CounterOracle<Integer, Boolean> counter;
			CacheOracle<Integer, Boolean> cache;
			ObservationTable<Integer, Boolean> table;
			Moore<?, Integer, Boolean> hyp;

			Moore<Map<Integer, Boolean>, Integer, Boolean> ref;
			Oracle<Integer, Boolean> oracle;

			int bin;
			//do {
				ref = NFA.random(seed++, states, alphabet, (int)Math.round(nfaSize * transitionDensity), (int)Math.round(nfaSize * acceptDensity));
				oracle = new MooreOracle<Map<Integer, Boolean>, Integer, Boolean>(ref);

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
				bin = hyp.size() / binSize;
			//} while (bin >= bins);
			if (bin < bins) {
				lstar.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				lstarMP.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new MooreObservationTable<Integer, Boolean>(cache);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				lstarRS.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
				nlstarMP.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
				nlstarMPNC.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
				nlstarRS.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());

				counter = new CounterOracle<Integer, Boolean>(oracle);
				cache = new CacheOracle<Integer, Boolean>(counter);
				table = new RFSAObservationTable<Integer>(cache, true);
				hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
				nlstarRSNC.add(bin, counter.getEQCount(), counter.getMQCount(), hyp.size());
			}
		}

		lstar.write("experiments/nfa/reordered_lstar");
		lstarMP.write("experiments/nfa/reordered_lstarMP");
		lstarRS.write("experiments/nfa/reordered_lstarRS");
		nlstarMP.write("experiments/nfa/reordered_nlstarMP");
		nlstarMPNC.write("experiments/nfa/reordered_nlstarMPNC");
		nlstarRS.write("experiments/nfa/reordered_nlstarRS");
		nlstarRSNC.write("experiments/nfa/reordered_nlstarRSNC");
	}

	public static void main(String[] args) {
		runDFAExperiments();
		runMooreExperiments();
		runWFAVanillaExperiments();
		runWFAonMooreExperiments();
		runWFAExperiments();
		runNFAExperiments();
		runReorderedNFAExperiments();
	}
}
