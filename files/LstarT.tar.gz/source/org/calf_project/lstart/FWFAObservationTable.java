package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class FWFAObservationTable<F, A> extends WFAObservationTable<F, A, F> {
	protected Field<F> f;

	public FWFAObservationTable(Oracle<A, F> oracle, Field<F> f, List<F> values) {
		super(oracle, f, f, values);
		this.f = f;
	}

	@Override
	public boolean hasRow(List<F> row) {
		List<List<F>> matrix = new ArrayList<List<F>>();
		List<List<F>> rows = new ArrayList<List<F>>(ttable.values());
		int n = row.size();
		for (int i = 0; i < n; i++)
			matrix.add(new ArrayList<F>());
		for (int i = 0; i < rows.size(); i++) {
			List<F> current = rows.get(i);
			for (int j = 0; j < n; j++)
				matrix.get(j).add(current.get(j));
		}
		for (int j = 0; j < n; j++)
			matrix.get(j).add(row.get(j));
		return GaussianElimination.gaussianElimination(matrix, f) != null;
	}

	@Override
	public boolean consistent() {
		List<List<A>> labels = new ArrayList<List<A>>(ttable.keySet());
		List<List<F>> matrix = new ArrayList<List<F>>();
		for (List<A> label : labels) {
			List<F> row = new ArrayList<F>(ttable.get(label));
			row.add(null);
			matrix.add(row);
		}
		int i = 0;
		for (List<A> columnLabel : columns) {
			for (A a : alphabet) {
				List<F> column = getColumn(labels, a, i);
				int j = 0;
				for (List<F> row : matrix)
					row.set(row.size() - 1, column.get(j++));
				if (GaussianElimination.gaussianElimination(matrix, f) == null) {
					List<A> newColumn = new ArrayList<A>();
					newColumn.add(a);
					newColumn.addAll(columnLabel);
					if (columns.contains(newColumn)) {
						System.out.println("Consistency: attempted to add existing column");
						System.exit(0);
					}
					addColumn(newColumn);
					return false;
				}
			}
			i++;
		}
		return true;
	}

	@Override
	protected Map<List<A>, F> decompose(List<F> row, List<List<A>> labels) {
		List<List<F>> matrix = new ArrayList<List<F>>();
		List<List<F>> rows = new ArrayList<List<F>>();
		for (List<A> label : labels)
			rows.add(ttable.get(label));
		int n = row.size();
		for (int i = 0; i < n; i++)
			matrix.add(new ArrayList<F>());
		for (int i = 0; i < rows.size(); i++) {
			List<F> current = rows.get(i);
			for (int j = 0; j < n; j++)
				matrix.get(j).add(current.get(j));
		}
		for (int i = 0; i < n; i++)
			matrix.get(i).add(row.get(i));
		List<F> weights = GaussianElimination.gaussianElimination(matrix, f);
		if (weights == null)
			return null;
		Map<List<A>, F> result = new HashMap<List<A>, F>();
		int i = 0;
		for (List<A> label : labels)
			result.put(label, weights.get(i++));
		return result;
	}
}
