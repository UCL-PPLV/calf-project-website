package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;

class MFAObservationTable<M, A, O> extends ObservationTable<A, O> {
	protected Monoid<M> m;
	protected MonoidAction<M, O> ma;
	protected List<M> values;
	protected MFA<M, List<A>, A, O> hyp;

	public MFAObservationTable(Oracle<A, O> oracle, Monoid<M> m, MonoidAction<M, O> ma, List<M> values) {
		super(oracle);
		this.m = m;
		this.ma = ma;
		this.values = values;
	}

	protected List<O> tableAction(M v, List<O> row) {
		List<O> result = new ArrayList<O>();
		for (O o : row)
			result.add(ma.mult(v, o));
		return result;
	}

	public boolean hasRow(List<O> row) {
		for (M v : values) {
			for (List<O> other : ttable.values()) {
				if (tableAction(v, other).equals(row))
					return true;
			}
		}
		return false;
	}

	public boolean consistent() {
		for (M v1 : values) {
			for (Map.Entry<List<A>, List<O>> entry1 : ttable.entrySet()) {
				for (M v2 : values) {
					for (Map.Entry<List<A>, List<O>> entry2 : ttable.entrySet()) {
						if (tableAction(v1, entry1.getValue()).equals(tableAction(v2, entry2.getValue()))) {
							for (A a : alphabet) {
								List<A> label1 = new ArrayList<A>(entry1.getKey());
								label1.add(a);

								List<A> label2 = new ArrayList<A>(entry2.getKey());
								label2.add(a);

								List<O> row1 = tableAction(v1, btable.get(label1));
								List<O> row2 = tableAction(v2, btable.get(label2));

								if (fixDiscrepancy(row1, row2, a))
									return false;
							}
						}
					}
				}
			}
		}
		return true;
	}

	protected List<List<A>> minimise() {
		List<List<A>> result = new ArrayList<List<A>>(ttable.keySet());
		java.util.Collections.reverse(result);
		Iterator<List<A>> it = result.iterator();
		while (it.hasNext()) {
			List<A> s = it.next();
			List<O> row = ttable.get(s);
			boolean stop = false;
			for (List<A> other : result) {
				if (!other.equals(s)) {
					for (M v : values) {
						if (tableAction(v, ttable.get(other)).equals(row)) {
							it.remove();
							stop = true;
							break;
						}
					}
					if (stop)
						break;
				}
			}
		}
		return result;
	}

	protected Tuple<M, List<A>> decompose(List<O> row, List<List<A>> rows) {
		for (M v : values) {
			for (List<A> s : rows) {
				if (tableAction(v, ttable.get(s)).equals(row))
					return new Tuple<M, List<A>>(v, s);
			}
		}
		return null;
	}

	protected O distortedMembership(List<A> own, List<A> other) {
		Tuple<M, List<A>> t = hyp.getState(own);
		List<A> word = new ArrayList<A>(t.getSnd());
		word.addAll(other);
		return ma.mult(t.getFst(), oracle.membership(word));
	}

	public MFA<M, List<A>, A, O> hypothesis() {
		List<List<A>> minimal = minimise();
		hyp = new MFA<M, List<A>, A, O>(decompose(ttable.get(new ArrayList<A>()), minimal), m, ma);

		for (List<A> label : minimal) {
			hyp.setOutput2(label, ttable.get(label).get(0));
			for (A a : alphabet) {
				List<A> labela = new ArrayList<A>(label);
				labela.add(a);
				hyp.addTransition(label, a, decompose(btable.get(labela), minimal));
			}
		}

		return hyp;
	}
}
