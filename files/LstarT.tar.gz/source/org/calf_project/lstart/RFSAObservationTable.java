package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class RFSAObservationTable<A> extends NFAObservationTable<A> {
	public RFSAObservationTable(Oracle<A, Boolean> oracle, boolean simplify) {
		super(oracle, simplify);
	}

	@Override
	public boolean consistent() {
		for (Map.Entry<List<A>, List<Boolean>> entry1 : ttable.entrySet()) {
			for (Map.Entry<List<A>, List<Boolean>> entry2 : ttable.entrySet()) {
				if (NFAObservationTable.lt(entry1.getValue(), entry2.getValue())) {
					for (A a : alphabet) {
						List<A> label1 = new ArrayList<A>(entry1.getKey());
						label1.add(a);

						List<A> label2 = new ArrayList<A>(entry2.getKey());
						label2.add(a);

						List<Boolean> row1 = btable.get(label1);
						List<Boolean> row2 = btable.get(label2);

						int i = 0;
						for (List<A> column : columns) {
							if (row1.get(i) && !row2.get(i)) {
								List<A> add = new ArrayList<A>();
								add.add(a);
								add.addAll(column);
								addColumn(add);
								return false;
							}
							i++;
						}
					}
				}
			}
		}
		return true;
	}
}
