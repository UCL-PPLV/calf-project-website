package org.calf_project.lstart;

import java.util.List;

public interface Oracle<A, O> extends Language<A, O> {
	public List<A> alphabet();
	public List<A> equivalence(Moore<?, A, O> hyp);
}
