package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class GaussianElimination {
	public static <F> List<F> gaussianElimination(List<List<F>> matrix, Field<F> f) {
		int rows = matrix.size();
		int cols = matrix.get(0).size();
		List<List<F>> temp = matrix;
		matrix = new ArrayList<List<F>>();
		for (List<F> row : temp)
			matrix.add(new ArrayList<F>(row));
		F zero = f.zero();

		int p = 0;
		List<Integer> indices = new ArrayList<Integer>();
		for (int i = 0; i < cols - 1 && p < rows; i++) {
			for (int j = p; j < rows; j++) {
				List<F> row = matrix.get(j);
				if (!row.get(i).equals(zero)) {
					matrix.set(j, matrix.get(p));
					matrix.set(p++, row);
					indices.add(i);
					for (int k = p; k < rows; k++) {
						List<F> other = matrix.get(k);
						F c = f.div(other.get(i), row.get(i));
						for (int l = 0; l < cols; l++)
							other.set(l, f.minus(other.get(l), f.mult(c, row.get(l))));
					}
					break;
				}
			}
		}

		for (int i = p; i < rows; i++) {
			if (!matrix.get(i).get(cols - 1).equals(zero))
				return null;
		}

		List<F> result = new ArrayList<F>();
		for (int i = 0; i < cols - 1; i++)
			result.add(zero);
		for (int i = p - 1; i >= 0; i--) {
			List<F> row = matrix.get(i);
			F v = row.get(cols - 1);
			int column = indices.get(i);
			for (int j = column + 1; j < cols - 1; j++)
				v = f.minus(v, f.mult(row.get(j), result.get(j)));
			result.set(column, f.div(v, row.get(column)));
		}
		return result;
	}
}
