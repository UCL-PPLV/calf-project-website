package org.calf_project.lstart;

public abstract class Field<F> extends Ring<F> {
	public abstract F invert(F f);

	public F div(F a, F b) {
		return mult(a, invert(b));
	}
}
