package org.calf_project.lstart;

import java.util.List;

public class OracleExtender<A, O> implements Oracle<A, O> {
	protected Oracle<A, O> oracle;

	public OracleExtender(Oracle<A, O> oracle) {
		this.oracle = oracle;
	}

	public List<A> alphabet() {
		return oracle.alphabet();
	}

	public O membership(List<A> word) {
		return oracle.membership(word);
	}

	public List<A> equivalence(Moore<?, A, O> hyp) {
		return oracle.equivalence(hyp);
	}
}
