package org.calf_project.lstart;

public class Result extends Tuple<Double, Double> {
	public Result(double average, double stddev) {
		super(average, stddev);
	}
}
