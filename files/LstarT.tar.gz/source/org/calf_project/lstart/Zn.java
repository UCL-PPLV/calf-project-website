package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class Zn extends Field<Integer> {
	private int n;
	private List<Integer> values;

	public Zn(int n) {
		this.n = n;
		values = new ArrayList<Integer>();
		for (int i = 0; i < n; i++)
			values.add(i);
	}

	public List<Integer> values() {
		return values;
	}

	public Integer zero() {
		return 0;
	}

	public Integer one() {
		return 1;
	}

	public Integer negate(Integer a) {
		return n - a;
	}

	public Integer invert(Integer a) {
		int result = 1;
		for (int i = 0; i < n - 2; i++)
			result = (result * a) % n;
		return result;
	}

	public Integer add(Integer a, Integer b) {
		return (a + b) % n;
	}

	public Integer mult(Integer a, Integer b) {
		return (a * b) % n;
	}
}
