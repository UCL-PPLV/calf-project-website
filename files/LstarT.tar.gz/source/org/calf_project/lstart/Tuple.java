package org.calf_project.lstart;

public class Tuple<A, B> {
	private A a;
	private B b;
	private boolean ignoreSnd;

	public Tuple(A a, B b) {
		if (a == null || b == null) {
			System.out.println("Tuple with null value");
			(new Exception()).printStackTrace();
			System.exit(0);
		}
		this.a = a;
		this.b = b;
		ignoreSnd = false;
	}

	public void ignoreSnd() {
		ignoreSnd = true;
	}

	public A getFst() {
		return a;
	}

	public B getSnd() {
		return b;
	}

	@Override
	public boolean equals(Object other) {
		if (other == null || !(other instanceof Tuple<?, ?>))
			return false;
		Tuple<?, ?> t = (Tuple<?, ?>)other;
		return a.equals(t.a) && ((ignoreSnd && t.ignoreSnd) || b.equals(t.b));
	}

	@Override
	public int hashCode() {
		return 5 + 31 * a.hashCode() + (ignoreSnd ? 0 : 17 * b.hashCode());
	}

	@Override
	public String toString() {
		return "(" + a.toString() + ", " + b.toString() + ")";
	}
}
