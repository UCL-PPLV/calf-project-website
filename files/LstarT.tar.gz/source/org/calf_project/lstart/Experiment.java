package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class Experiment {
	private List<String> labels;
	private List<Results> eqResults;
	private List<Results> mqResults;
	private List<Results> sizeResults;
	private int n;

	public Experiment() {
		labels = new ArrayList<String>();
		eqResults = new ArrayList<Results>();
		mqResults = new ArrayList<Results>();
		sizeResults = new ArrayList<Results>();
		n = 0;
		start();
	}

	private void start() {
		eqResults.add(new Results());
		mqResults.add(new Results());
		sizeResults.add(new Results());
	}

	public void add(int index, int eqs, int mqs, int size) {
		eqResults.get(index).add((double)eqs);
		mqResults.get(index).add((double)mqs);
		sizeResults.get(index).add((double)size);
	}

	public void add(int eqs, int mqs, int size) {
		add(n, eqs, mqs, size);
	}

	public void save(String label) {
		labels.add(label);
		n++;
		start();
	}

	private void writeSingle(String name, List<Results> results) {
		BufferedWriter output = null;
		try {
			File file = new File(name);
			output = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < n; i++) {
				Result result = results.get(i).summarise();
				output.write(labels.get(i) + " " + result.getFst() + " " + result.getSnd());
				output.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void write(String name) {
		writeSingle(name + "_eq.dat", eqResults);
		writeSingle(name + "_mq.dat", mqResults);
		writeSingle(name + "_size.dat", sizeResults);

		BufferedWriter output = null;
		try {
			File file = new File(name + "_dist.dat");
			output = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < n; i++) {
				output.write(labels.get(i) + " " + eqResults.get(i).size());
				output.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
