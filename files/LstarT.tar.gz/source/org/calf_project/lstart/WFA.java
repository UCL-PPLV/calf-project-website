package org.calf_project.lstart;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class WFA<S, Q, A, O> extends Moore<Map<Q, S>, A, O> {
	protected Semiring<S> sr;
	protected Semimodule<S, O> sm;

	public WFA(Map<Q, S> initial, Semiring<S> sr, Semimodule<S, O> sm) {
		super(initial);
		this.sr = sr;
		this.sm = sm;
	}

	protected Map<Q, S> unit(Q q) {
		Map<Q, S> single = new HashMap<Q, S>();
		single.put(q, sr.one());
		return single;
	}

	public void addTransition(Q origin, A a, Map<Q, S> target) {
		addTransition(unit(origin), a, target);
	}

	public void setOutput2(Q q, O o) {
		setOutput(unit(q), o);
	}

	@Override
	protected Map<Q, S> advance(Map<Q, S> qs, A a) {
		Map<Q, S> result = new HashMap<Q, S>();
		for (Map.Entry<Q, S> entry1 : qs.entrySet()) {
			Map<Q, S> extra = super.advance(unit(entry1.getKey()), a);
			for (Map.Entry<Q, S> entry2 : extra.entrySet()) {
				Q q = entry2.getKey();
				S value = sr.mult(entry1.getValue(), entry2.getValue());
				S old = result.get(q);
				result.put(q, old == null ? value : sr.add(old, value));
			}
		}
		return result;
	}

	@Override
	protected O output(Map<Q, S> qs) {
		O result = sm.zero();
		for (Map.Entry<Q, S> entry : qs.entrySet())
			result = sm.add(result, sm.mult(entry.getValue(), super.output(unit(entry.getKey()))));
		return result;
	}

	public static <S, Q, A, O> WFA<S, Q, A, O> random(long seed, List<Q> states, List<A> symbols, List<O> outputs, Semiring<S> sr, Semimodule<S, O> sm, List<S> values) {
		Random random = new Random(seed);
		Map<Q, S> initial = new HashMap<Q, S>();
		for (Q q : states)
			initial.put(q, values.get(random.nextInt(values.size())));
		WFA<S, Q, A, O> result = new WFA<S, Q, A, O>(initial, sr, sm);
		for (Q q : states) {
			result.setOutput2(q, outputs.get(random.nextInt(outputs.size())));
			for (A a : symbols) {
				Map<Q, S> target = new HashMap<Q, S>();
				for (Q q2 : states)
					target.put(q2, values.get(random.nextInt(values.size())));
				result.addTransition(q, a, target);
			}
		}
		return result;
	}
}
