package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public abstract class ObservationTable<A, O> {
	public static enum CounterexampleHandler {
		ANGLUIN,
		MALER_PNUELI,
		RIVEST_SCHAPIRE
	}

	protected List<List<A>> columns;
	protected Map<List<A>, List<O>> ttable;
	protected Map<List<A>, List<O>> btable;
	protected Oracle<A, O> oracle;
	protected List<A> alphabet;

	public ObservationTable(Oracle<A, O> oracle) {
		this.oracle = oracle;
		this.alphabet = oracle.alphabet();

		columns = new ArrayList<List<A>>();

		ttable = new HashMap<List<A>, List<O>>();
		btable = new HashMap<List<A>, List<O>>();
	}

	public void addRow(List<A> label) {
		if (ttable.containsKey(label))
			return;

		List<O> row = new ArrayList<O>();
		for (List<A> column : columns) {
			List<A> word = new ArrayList<A>(label);
			word.addAll(column);
			row.add(oracle.membership(word));
		}
		ttable.put(label, row);

		for (A a : alphabet) {
			List<A> labela = new ArrayList<A>(label);
			labela.add(a);

			row = new ArrayList<O>();
			for (List<A> column : columns) {
				List<A> word = new ArrayList<A>(labela);
				word.addAll(column);
				row.add(oracle.membership(word));
			}
			btable.put(labela, row);
		}
	}

	public void addColumn(List<A> column) {
		if (columns.contains(column))
			return;

		columns.add(column);

		for (Map.Entry<List<A>, List<O>> entry : ttable.entrySet()) {
			List<A> word = new ArrayList<A>(entry.getKey());
			word.addAll(column);
			entry.getValue().add(oracle.membership(word));
		}

		for (Map.Entry<List<A>, List<O>> entry : btable.entrySet()) {
			List<A> word = new ArrayList<A>(entry.getKey());
			word.addAll(column);
			entry.getValue().add(oracle.membership(word));
		}
	}

	protected List<O> getColumn(List<List<A>> rows, int i) {
		List<O> result = new ArrayList<O>();
		for (List<A> row : rows)
			result.add(ttable.get(row).get(i));
		return result;
	}

	protected List<O> getColumn(List<List<A>> rows, A a, int i) {
		List<O> result = new ArrayList<O>();
		for (List<A> row : rows) {
			List<A> rowa = new ArrayList<A>(row);
			rowa.add(a);
			result.add(btable.get(rowa).get(i));
		}
		return result;
	}

	public abstract boolean hasRow(List<O> row);

	public boolean closed() {
		for (Map.Entry<List<A>, List<O>> entry : btable.entrySet()) {
			if (!hasRow(entry.getValue())) {
				List<A> label = entry.getKey();
				if (ttable.containsKey(label)) {
					System.out.println("Closedness: attempted to add existing row");
					System.exit(0);
				}
				addRow(label);
				return false;
			}
		}
		return true;
	}

	protected boolean fixDiscrepancy(List<O> row1, List<O> row2, A a) {
		int i = 0;
		for (List<A> column : columns) {
			if (!row1.get(i).equals(row2.get(i))) {
				List<A> add = new ArrayList<A>();
				add.add(a);
				add.addAll(column);
				addColumn(add);
				return true;
			}
			i++;
		}
		return false;
	}

	public abstract boolean consistent();

	private void prepare(boolean consistency) {
		while (!closed() || (consistency && !consistent()))
			;
		return;
	}

	public abstract Moore<?, A, O> hypothesis();

	private void angluinCounterexample(List<A> ce) {
		if (ttable.containsKey(ce)) {
			System.out.println("Angluin: attempted to add existing row");
			System.exit(0);
		}
		for (int i = 0; i <= ce.size(); i++)
			addRow(ce.subList(0, i));
	}

	private void mpCounterexample(List<A> ce) {
		if (columns.contains(ce)) {
			System.out.println("MP: attempted to add existing column");
			System.exit(0);
		}
		for (int i = 0; i < ce.size(); i++)
			addColumn(ce.subList(i, ce.size()));
		addColumn(new ArrayList<A>());
	}

	protected abstract O distortedMembership(List<A> own, List<A> other);

	private void rsCounterexample(List<A> ce) {
		if (distortedMembership(new ArrayList<A>(), ce).equals(distortedMembership(ce, new ArrayList<A>()))) {
			if (columns.contains(ce)) {
				System.out.println("RS: attempted to add existing column");
				System.exit(0);
			}
			addColumn(ce);
			return;
		}
		O actual = oracle.membership(ce);
		List<A> pre = new ArrayList<A>();
		List<A> x = ce;
		List<A> post = new ArrayList<A>();
		while (x.size() > 1) {
			int middle = x.size() / 2;
			List<A> u = x.subList(0, middle);
			List<A> v = x.subList(middle, x.size());
			List<A> start = new ArrayList<A>(pre);
			start.addAll(u);
			List<A> end = new ArrayList<A>(v);
			end.addAll(post);
			if (distortedMembership(start, end).equals(actual)) {
				pre = start;
				x = v;
			} else {
				post = end;
				x = u;
			}
		}
		if (columns.contains(post)) {
			System.out.println("RS: attempted to add existing column");
			System.exit(0);
		}
		addColumn(post);
	}

	public Moore<?, A, O> lstar(CounterexampleHandler ceHandler, boolean consistency) {
		addColumn(new ArrayList<A>());
		addRow(new ArrayList<A>());

		List<A> ce;
		Moore<?, A, O> hyp;
		do {
			prepare(consistency);
			hyp = hypothesis();
			ce = oracle.equivalence(hyp);
			if (ce != null) {
				switch (ceHandler) {
					case ANGLUIN:
						angluinCounterexample(ce);
						break;
					case MALER_PNUELI:
						mpCounterexample(ce);
						break;
					case RIVEST_SCHAPIRE:
						rsCounterexample(ce);
						break;
				}
			}
		} while (ce != null);
		return hyp;
	}
}
