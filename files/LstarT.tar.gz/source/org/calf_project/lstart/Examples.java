package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class Examples {
	public static void testUnion() {
		Moore<Integer, Character, Boolean> dfa = new Moore<Integer, Character, Boolean>(0);
		dfa.setOutput(0, true);
		dfa.setOutput(1, false);
		dfa.setOutput(2, true);
		dfa.addTransition(0, 'a', 1);
		dfa.addTransition(1, 'a', 2);
		dfa.addTransition(2, 'a', 2);
		MooreOracle<Integer, Character, Boolean> oracle = new MooreOracle<Integer, Character, Boolean>(dfa);

		CounterOracle<Character, Boolean> counter;
		CacheOracle<Character, Boolean> cache;
		ObservationTable<Character, Boolean> table;

		counter = new CounterOracle<Character, Boolean>(oracle);
		cache = new CacheOracle<Character, Boolean>(counter);
		table = new MooreObservationTable<Character, Boolean>(cache);
		System.out.println(table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true));
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Character, Boolean>(oracle);
		cache = new CacheOracle<Character, Boolean>(counter);
		table = new NFAObservationTable<Character>(cache, true);
		System.out.println(table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true));
		counter.printStatus();
	}

	public static void testRandomNFA() {
		List<Integer> states = new ArrayList<Integer>();
		int n = 8;
		int k = 2;
		for (int i = 0; i < n; i++)
			states.add(i);
		List<Integer> alphabet = new ArrayList<Integer>();
		for (int i = 0; i < k; i++)
			alphabet.add(i);
		Oracle<Integer, Boolean> oracle = new MooreOracle<Map<Integer, Boolean>, Integer, Boolean>(NFA.random(5, states, alphabet, (int)Math.round(n * 1.25), (int)Math.round(n * 0.5)));

		CounterOracle<Integer, Boolean> counter;
		CacheOracle<Integer, Boolean> cache;
		ObservationTable<Integer, Boolean> table;
		Moore<?, Integer, Boolean> hyp;

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new MooreObservationTable<Integer, Boolean>(cache);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
		System.out.println("L*");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new MooreObservationTable<Integer, Boolean>(cache);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
		System.out.println("L* MP");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new MooreObservationTable<Integer, Boolean>(cache);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
		System.out.println("L* RS");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new NFAObservationTable<Integer>(cache, true);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true);
		System.out.println("L*P");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new RFSAObservationTable<Integer>(cache, true);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, true);
		System.out.println("NL* MP");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new NFAObservationTable<Integer>(cache, true);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.MALER_PNUELI, false);
		System.out.println("NL* MP - cons");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new RFSAObservationTable<Integer>(cache, true);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, true);
		System.out.println("NL* RS");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
		System.out.println("---");

		counter = new CounterOracle<Integer, Boolean>(oracle);
		cache = new CacheOracle<Integer, Boolean>(counter);
		table = new NFAObservationTable<Integer>(cache, true);
		hyp = table.lstar(ObservationTable.CounterexampleHandler.RIVEST_SCHAPIRE, false);
		System.out.println("NL* RS - cons");
		System.out.println("size: " + hyp.size());
		counter.printStatus();
	}

	public static class Mod implements Monoid<Integer>, MonoidAction<Integer, Integer> {
		private int n;
		private List<Integer> values;

		public Mod(int n) {
			this.n = n;
			values = new ArrayList<Integer>();
			for (int i = 0; i < n; i++)
				values.add(i);
		}

		public List<Integer> values() {
			return values;
		}

		public Integer zero() {
			return 0;
		}

		public Integer add(Integer a, Integer b) {
			return (a + b) % n;
		}

		public Integer mult(Integer a, Integer b) {
			return add(a, b);
		}
	}

	public static void testRotation() {
		int n = 10;
		Moore<Integer, Character, Integer> moore = new Moore<Integer, Character, Integer>(0);
		for (int i = 0; i < n; i++) {
			moore.setOutput(i, i);
			moore.addTransition(i, 'a', (i + 1) % n);
		}
		MooreOracle<Integer, Character, Integer> oracle = new MooreOracle<Integer, Character, Integer>(moore);

		CounterOracle<Character, Integer> counter;
		CacheOracle<Character, Integer> cache;
		ObservationTable<Character, Integer> table;

		counter = new CounterOracle<Character, Integer>(oracle);
		cache = new CacheOracle<Character, Integer>(counter);
		table = new MooreObservationTable<Character, Integer>(cache);
		System.out.println(table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true));
		counter.printStatus();
		System.out.println("---");

		Mod z = new Mod(n);
		counter = new CounterOracle<Character, Integer>(oracle);
		cache = new CacheOracle<Character, Integer>(counter);
		table = new MFAObservationTable<Integer, Character, Integer>(cache, z, z, z.values());
		System.out.println(table.lstar(ObservationTable.CounterexampleHandler.ANGLUIN, true));
		counter.printStatus();
	}

	public static void main(String[] args) {
		testUnion();
	}
}
