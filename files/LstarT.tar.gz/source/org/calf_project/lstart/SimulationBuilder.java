package org.calf_project.lstart;

import java.util.List;
import java.util.ArrayList;

public class SimulationBuilder<A, B, E> {
	private List<Tuple<Tuple<A, B>, E>> contents;
	int i = 0;

	public SimulationBuilder() {
		contents = new ArrayList<Tuple<Tuple<A, B>, E>>();
	}

	public Boolean add(A a, B b, E e) {
		Tuple<Tuple<A, B>, E> t = new Tuple<Tuple<A, B>, E>(new Tuple<A, B>(a, b), e);
		t.ignoreSnd();

		if (contents.contains(t))
			return false;

		contents.add(t);
		return true;
	}

	public void advance() {
		i++;
	}

	public boolean done() {
		return i >= contents.size();
	}

	public A getA() {
		return contents.get(i).getFst().getFst();
	}

	public B getB() {
		return contents.get(i).getFst().getSnd();
	}

	public E getEtc() {
		return contents.get(i).getSnd();
	}
}
